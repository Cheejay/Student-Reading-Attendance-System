<?php
/*
 *	公共函数库 
 */
function check_verify($code, $id = ''){
	$verify = new \Think\Verify();
	return $verify->check($code, $id);
}

function think_ucenter_md5_admin($str, $key = 'ThinkUCenter'){
	return '' === $str ? '' : md5(sha1($str) . $key);
}

//返回书名
function getBookName($bookid){

	if(($bookid=='' || !is_numeric($bookid))){
		return 'error!not bookid!';
	}
	
	$book=M('BookList')->field('bookname')->where(array('id'=>$bookid))->find();
	return $book['bookname'];
	
}

/**
 * 数据签名认证
 */
function data_auth_sign($data) {
	//数据类型检测
	if(!is_array($data)){
		$data = (array)$data;
	}
	ksort($data); //排序
	$code = http_build_query($data); //url编码并生成query字符串
	$sign = sha1($code); //生成签名
	return $sign;
}


//检测用户是否登陆
function is_login(){
	$user = session('user_auth');
	if (empty($user)) {
		return 0;
	} else {
		return session('user_auth_sign') == data_auth_sign($user) ? $user['id'] : 0;
	}
}

//返回用户学号
function get_studentid(){
	$user = session('user_auth');
	if (empty($user)) {
		return 0;
	} else {
		return session('user_auth.studentid');
	}
}


//获取用户积分总和
function get_score(){
	
	$map['studentid'] = session('user_auth.studentid');
	$score=M('Member')->where($map)->field('score')->find();
	return $score['score'];
}


//获取数据库配置 $name是配置名称
function Config($name){

	$result=M('Config')->where(array('Cname'=>$name))->find();
	return $result['value'];

}



/*
 * 
 * 获取当前周期
 * $nowTime,开学的时间戳,也就是开学周期的星期一为时间
 * $oneD,每天的时间戳
 */
function getCycle(){
	
	$nowTime=Config('start');
	$oneD =86400;
	$time=time();
	
	for($i = 0;$i<365;$i++){
		$a=$nowTime + $oneD*$i;
		if($i<7){
			$zhouqi=1;
		}else{
			$zhouqi=$i / 7;
			$zhouqi=$zhouqi+1;
		}
		$zhouqi=explode('.', $zhouqi);

		if(date('Y-m-d' ,$time) == date('Y-m-d' ,$a)){
			return $zhouqi[0];
		}
	}

}


/*  返回这一周书本的id*/
function getBookId(){
	
	$bookn=D('WeeklySchedule')->getWs();
	return $bookn['bookid'];
	
}



/*查询连续签到的天数*/
function getCsd(){
	
	$csd=M('Sign')->field('continuous_sign_days')->where(array('studentid'=>get_studentid()))->find();	
	return $csd['continuous_sign_days'];
	
}

function getBookPage($bookid){
	$arr = M('BookList')->where(array('studentid'=>get_studentid(),'id'=>$bookid))->find();
	return $arr['bookpage'];
}



function getNowPage($bookid){
	
	$now = date('Y-m-d',time());
	$arr = M('nowdaySign')->where(array('studentid'=>get_studentid(),'sign_time'=>$now,'bookid'=>$bookid))->find();
	if($arr){
		return $arr['stoppage'];
	}else{
		return 0;
	}
	
	
}



function getNowNotes($bookid){

	$now = date('Y-m-d',time());
	$arr = M('nowdaySign')->where(array('studentid'=>get_studentid(),'sign_time'=>$now,'bookid'=>$bookid))->find();
	if($arr){
		return $arr['notes_amount'];
	}else{
		return 0;
	}


}



//过滤特殊字符,只允许用户输入数字，英文，中文
function gltszf($str){

	$zze="/^[0-9a-zA-Z_\x{4e00}-\x{9fa5}]+$/u";
	if(preg_match($zze,$str)){
		return true;
	}else{
		return false;
	}
}

function getStudentName($studentid=null){
    $data = M(member)->where(array('studentid'=>$studentid))->find();
    if($data){
        return $data['nickname'];
    }else{
        return false;
    }
}

function getStudentClass($studentid=null){
    $data = M(member)->where(array('studentid'=>$studentid))->find();
    if($data){
        return $data['classid'];
    }else{
        return false;
    }
}









