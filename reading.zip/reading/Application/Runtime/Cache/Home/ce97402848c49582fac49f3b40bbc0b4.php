<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE HTML>
<html>
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>一职悦读吧</title>
<link rel="shortcut icon" href="favicon.ico">
<link rel="stylesheet" href="/reading/Public/Home/css/Bootstrap.css">
<link rel="stylesheet" href="/reading/Public/Home/css/jquery.mobile.structure-1.4.5.min.css" />
<link href="/reading/Public/Home/css/mybook.css" rel="stylesheet" type="text/css">
<script src="/reading/Public/Home/js/jquery.js"></script>
<script src="/reading/Public/Home/js/jquery.mobile-1.4.5.min.js"></script>
<script type="text/javascript" src="/reading/Public/Home/js/preloader.js"></script>
<script>
	function getcode() {
	    var img = document.getElementById('get_img');
	    var dt = new Date();
	    img.src = "<?php echo U('Public/verify');?>?t=" + dt;
	}
	function alert1(){
		alert("初始帐号为学号，密码为学号，忘记密码的，上报班名和完整学号给班主任，班主任再统一交蔡老师处理。");
	}

</script>
</head>

<body>
<div data-role="page" data-theme="a" class="jqm-loginPage"> 
  <!--<div data-role="header" >
            <h1>欢迎</h1>
        </div>-->
  <div role="main" class="ui-content  jqm-login ">
    <div class="logo1">数字化阅读交流分享平台</div>
    <div class="logo2">一职悦读吧</div>
    <div class="mycenter"><img src="/reading/Public/Home/images/logo.png"   class="smallimage" ></div>
    <form action="<?php echo U('Public/login');?>" method="post" data-ajax="false">
      <div class="loginPanal  ">
      
        <div class="divright">
          <input type="text" name="studentid" id="txt_user" placeholder="请输入学号" value="" class="w100">
        </div>
        <div class="clear"></div>
       
        <div class="divright">
          <input type="password" name="password" id="txt_psw" placeholder="请输入密码" value="">
        </div>
        <div class="clear"></div>
        
        <div class="divright" style="width:100%;">
       		<div class="ui-grid-a">
       			 <div class="ui-block-a">
       			 	 <input type="text" name="verify" id="txt_psw" placeholder="请输入验证码" value="">
       			 </div>
       			 <div class="ui-block-b" style="margin-top:8px;padding-left:10px;">
       			 	<img class="verifyimg reloadverify" id="get_img" alt="点击切换" src="<?php echo U('Public/verify');?>" style="width:85%;height:38px;padding-left:14px;"onclick="getcode();return false;">
       			 </div>
       		</div>
        </div>
  
		<div class="clear"></div>
		<div class="divright login" style="width:100%;margin:10px 0 5px 0;">
            <input type="submit" data-mini="true" data-theme="c" value="登陆系统" style="background:red;">
        </div>
        <div class="ui-grid-a clear login" style="margin-bottom:30px;">
            <input type="button" data-mini="true" data-theme="a" value="忘记密码" onclick="alert1()">
        </div>
        <!--/demo-html --> 
      </div>
    </form>
  </div>
</div>

</body>
</html>