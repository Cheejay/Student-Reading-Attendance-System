<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE HTML>
<html>
<head>
	<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>爱读书</title>
<link rel="shortcut icon" href="favicon.ico">
<link rel="stylesheet" href="/reading/Public/Home/css/themes/default/jquery.mobile-1.4.5.min.css">
<link rel="stylesheet" href="/reading/Public/Home/css/jquery.mobile.structure-1.4.5.min.css" />
<link href="/reading/Public/Home/css/mybook.css" rel="stylesheet" type="text/css" />
<link rel="stylesheet" href="/reading/Public/Home/css/Bootstrap.css" />
<script src="/reading/Public/Home/js/app.js"></script>
<script src="/reading/Public/Home/js/jquery.js"></script>
<script src="/reading/Public/Home/js/jquery.mobile-1.4.5.min.js"></script>
<script type="text/javascript" src="/reading/Public/Home/js/preloader.js"></script>
<script type="text/javascript" src="/reading/Public/Home/js/pdf.worker.js"></script>
<script src="/reading/Public/Home/js/pdf.js"></script>

</head>
<body></block>
	<!-- 主体 -->
	
 <div data-role="page">
       <!--header-->
        <div data-role="header">
        <h1>好书推荐</h1>
        
          <a data-rel="back" data-icon="arrow-l" data-theme="a" data-iconpos="notext" data-ajax="false" class="back">后退</a>
          <a href="<?php echo U('Index/index');?>" data-icon="home" data-theme="a" data-iconpos="notext" data-ajax="false" class="back">查看</a>
        </div>
        <h1 class="onlineRead tc"><a href="<?php echo U('News/OnlineRead');?>" data-ajax="false">在线阅读</a></h1>       
         
           <!--content-->
<!--进度条 start-->
  <div id="preloader">
    <div id="status">
      <p class="center-text"> <em>请稍等，吐血加载中……<br>
        取决于你的网速!</em> </p>
    </div>
  </div>
  <!--进度条 end--> 
           <div data-role="content">
               <ul data-role="listview" data-inset="true" >
                  <?php if(is_array($data)): $i = 0; $__LIST__ = $data;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?><li>
                       <a href="<?php echo U('News/details');?>?id=<?php echo ($vo["id"]); ?>" data-ajax="false">
                       		<?php $a = str_replace('\\','/',$vo['picture']); ?>
                           <img src="/reading/Public/Uploads/<?php echo ($a); ?>" width="80" height="80" style="margin:6px 0 0  6px;"/>
                           <h3 style="font-weight:400;"><?php echo ($vo["title"]); ?></h3>
                           <p><?php echo ($vo["abstract"]); ?></p>
                       </a>
                   </li><?php endforeach; endif; else: echo "" ;endif; ?>
               </ul>
         </div>                  
       <!--footer-->    
 <div data-role="footer" data-position="fixed" data-tap-toggle="false" class="jqm-footer">
      <p style="margin-bottom:0;line-height:24px;color:#fff;">珠海一职语文课外阅读研究课题组</p>
      <p style="margin-top:0;margin-bottom:0;line-height:20px;font-size:0.7em;">一职悦读吧 </p>
</div>
    </div>

	<!-- /主体 -->

	<!-- 底部 -->
	 <!-- 用于加载js代码 -->
	<!-- /底部 -->
</body>
</html>