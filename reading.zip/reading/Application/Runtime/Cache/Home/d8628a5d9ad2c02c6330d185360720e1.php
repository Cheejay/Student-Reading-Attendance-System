<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE HTML>
<html>
<head>
	<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>爱读书</title>
<link rel="shortcut icon" href="favicon.ico">
<link rel="stylesheet" href="/reading/Public/Home/css/themes/default/jquery.mobile-1.4.5.min.css">
<link rel="stylesheet" href="/reading/Public/Home/css/jquery.mobile.structure-1.4.5.min.css" />
<link href="/reading/Public/Home/css/mybook.css" rel="stylesheet" type="text/css" />
<link rel="stylesheet" href="/reading/Public/Home/css/Bootstrap.css" />
<script src="/reading/Public/Home/js/app.js"></script>
<script src="/reading/Public/Home/js/jquery.js"></script>
<script src="/reading/Public/Home/js/jquery.mobile-1.4.5.min.js"></script>
<script type="text/javascript" src="/reading/Public/Home/js/preloader.js"></script>
<script type="text/javascript" src="/reading/Public/Home/js/pdf.worker.js"></script>
<script src="/reading/Public/Home/js/pdf.js"></script>

</head>
<body></block>
	<!-- 主体 -->
	
  <div data-role="page">
  <div class="shadow" style="width:100%;height:100vh;background:rgba(0,0,0,0.7);position:fixed;top:0;right:0;left:0;bottom:0;z-index:10;display:none;">
  	<div class="shadow-box" style="width:70%;height:15%;;background:#ccc;border-radius:6px;top:15%;left:50%;margin-left:-35%;position:absolute;text-align:center;line-height:15vh;font-size:1rem;">	
  		
  	</div>
  </div>
       <!--header-->
        <div data-role="header" data-position="fixed">
        <h1>每周排行</h1>
            <a href="home.html" data-icon="arrow-l"  data-theme="a" data-iconpos="notext" data-ajax="false" class="back">后退</a>
           	<a href="<?php echo U('Index/index');?>" data-icon="home" data-theme="a" data-iconpos="notext" data-ajax="false" class="back">查看</a>
         </div>
         
           <!--content-->
      <!--进度条 start-->
        <div id="preloader">
          <div id="status">
            <p class="center-text"> <em>请稍等，吐血加载中……<br>
              取决于你的网速!</em> </p>
          </div>
        </div>
        <!--进度条 end--> 
        <div data-role="content">
            <div data-role="collapsible" class="rank_all">
              <h1>每周热读书籍榜</h1>
              <div class="ui-grid-c rank">
                <!-- 标题start -->
                <div class="ui-block-a">
                  书名
                </div>
                <div class="ui-block-b">
                    作者
                </div>
                <div class="ui-block-c">
                    阅读人次
                </div>
                <div class="ui-block-d">
                  排名
                </div>

                 <!-- 标题end -->
                 <?php if(is_array($book)): foreach($book as $i=>$vo): ?><!-- 循环数据start -->
                 <div class="ui-block-a czp" onclick="">
                  	《<?php echo ($vo['bookname']); ?>》
                </div>
                <div class="ui-block-b">
                  <?php echo ($vo['author']); ?>
                </div>
                 <div class="ui-block-c">
                     <?php echo ($vo['number']); ?>
                 </div>
                 <div class="ui-block-d">
                     <?php echo ($i+1); ?>
                 </div>
                <!-- 循环数据end --><?php endforeach; endif; ?>
              </div>
            </div>
            <div data-role="collapsible" class="rank_all">
              <h1>每周香华校区读书之星</h1>
              <div class="ui-grid-c rank">
                <!-- 标题start -->
                <div class="ui-block-a">
                  姓名
                </div>
                <div class="ui-block-b">
                  班级
                </div>
                <div class="ui-block-c">
                  积分
                </div>
                 <div class="ui-block-d">
                  积分排名
                </div>
                 <!-- 标题end -->
                 <?php if(is_array($score_branch)): foreach($score_branch as $i=>$vo): ?><!-- 循环数据start -->
                 <div class="ui-block-a">
                  	<?php echo ($vo['nickname']); ?>
                </div>
                <div class="ui-block-b">
                  <?php echo ($vo['classid']); ?>
                </div>
                <div class="ui-block-c">
                  <?php echo ($vo['score']); ?>
                </div>
                <div class="ui-block-d">
                  <?php echo ($i+1); ?>
                </div>
                <!-- 循环数据end --><?php endforeach; endif; ?>              </div>
            </div>
            <div data-role="collapsible" class="rank_all">
              <h1>每周主校区读书之星</h1>
              <div class="ui-grid-c rank">
                <!-- 标题start -->
                <div class="ui-block-a">
                  姓名
                </div>
                <div class="ui-block-b">
                  班级
                </div>
                <div class="ui-block-c">
                  积分
                </div>
                 <div class="ui-block-d">
                  积分排名
                </div>
                 <!-- 标题end -->
                 <?php if(is_array($score_main)): foreach($score_main as $i=>$vo): ?><!-- 循环数据start -->
                 <div class="ui-block-a">
                  	<?php echo ($vo['nickname']); ?>
                </div>
                <div class="ui-block-b">
                  <?php echo ($vo['classid']); ?>
                </div>
                <div class="ui-block-c">
                  <?php echo ($vo['score']); ?>
                </div>
                <div class="ui-block-d">
                  <?php echo ($i+1); ?>
                </div>
                <!-- 循环数据end --><?php endforeach; endif; ?>              </div>
            </div>
              <div data-role="collapsible" class="rank_all">
              <h1>每周班级读书之星</h1>
              <div class="ui-grid-c rank">
                <!-- 标题start -->
                <div class="ui-block-a">
                  姓名
                </div>
                <div class="ui-block-b">
                  班级
                </div>
                <div class="ui-block-c">
                  积分
                </div>
                <div class="ui-block-d">
                  积分排名
                </div>
                 <!-- 标题end -->
			<?php if(is_array($score_class)): foreach($score_class as $i=>$vo): ?><!-- 循环数据start -->
                 <div class="ui-block-a">
                  	<?php echo ($vo['nickname']); ?>
                </div>
                <div class="ui-block-b">
                  <?php echo ($vo['classid']); ?>
                </div>
                <div class="ui-block-c">
                  <?php echo ($vo['score']); ?>
                </div>
                <div class="ui-block-c">
                  <?php echo ($i+1); ?>
                </div>
                <!-- 循环数据end --><?php endforeach; endif; ?>                       </div>
            </div>
            <div data-role="collapsible" class="rank_all">
              <h1>每周香华校区悦读班级</h1>
              <div class="ui-grid-d rank">
                <!-- 标题start -->
                <div class="ui-block-d" style="font-size:0.8rem;">
                  班级
                </div>
                <div class="ui-block-d"style="font-size:0.8rem;">
                   签到人次
                </div>
               
                  <div class="ui-block-d"style="font-size:0.8rem;">
                  平均积分
                </div>
                <div class="ui-block-d"style="font-size:0.8rem;">
                  总积分
                </div>
                <div class="ui-block-d"style="font-size:0.8rem;">
                  排名
                </div>
                 <!-- 标题end -->
                <?php if(is_array($class_branch)): foreach($class_branch as $i=>$vo): ?><!-- 循环数据start -->
                 <div class="ui-block-d">
                  	<?php echo ($vo['classid']); ?>
                </div>
                <div class="ui-block-d">
                  <?php echo ((isset($vo['total_days']) && ($vo['total_days'] !== ""))?($vo['total_days']):0); ?>
                </div>
               
                 <div class="ui-block-d">
               	<?php echo ($vo['avg_score']); ?>
                </div>	
                <div class="ui-block-d">
                  <?php echo ($vo['score']); ?>
                </div>
                <div class="ui-block-d">
                  <?php echo ($i+1); ?>
                </div>
                <!-- 循环数据end --><?php endforeach; endif; ?>
              </div>
            </div>
            <div data-role="collapsible" class="rank_all">
              <h1>每周主校区悦读班级</h1>
              <div class="ui-grid-d rank">
                <!-- 标题start -->
                <div class="ui-block-d" style="font-size:0.8rem;">
                  班级
                </div>
                <div class="ui-block-d"style="font-size:0.8rem;">
                   签到人次
                </div>
               
                  <div class="ui-block-d"style="font-size:0.8rem;">
                  平均积分
                </div>
                <div class="ui-block-d"style="font-size:0.8rem;">
                  总积分
                </div>
                <div class="ui-block-d"style="font-size:0.8rem;">
                  排名
                </div>
                 <!-- 标题end -->
                <?php if(is_array($class_main)): foreach($class_main as $i=>$vo): ?><!-- 循环数据start -->
                 <div class="ui-block-d">
                  	<?php echo ($vo['classid']); ?>
                </div>
                <div class="ui-block-d">
                  <?php echo ((isset($vo['total_days']) && ($vo['total_days'] !== ""))?($vo['total_days']):0); ?>
                </div>
               
                 <div class="ui-block-d">
               	<?php echo ($vo['avg_score']); ?>
                </div>	
                <div class="ui-block-d">
                  <?php echo ($vo['score']); ?>
                </div>
                <div class="ui-block-d">
                  <?php echo ($i+1); ?>
                </div>
                <!-- 循环数据end --><?php endforeach; endif; ?>
              </div>
            </div>
        </div>
           
         
       <!--footer-->    
 <div data-role="footer" data-position="fixed" data-tap-toggle="false" class="jqm-footer">
      <p style="margin-bottom:0;line-height:24px;color:#fff;">珠海一职语文课外阅读研究课题组</p>
      <p style="margin-top:0;margin-bottom:0;line-height:20px;font-size:0.7em;">一职悦读吧 </p>
</div>
    </div>

 <script>
 $(function(){
	 $('.shadow').click(function(){
		 $(this).hide('1000');
		 $('.shadow-box').text('');
	 });
	 $('.czp').bind('click',function(){
		$('.shadow').show('1000');
		$('.shadow-box').text($(this).text());
	 });
 });
 </script>


	<!-- /主体 -->

	<!-- 底部 -->
	 <!-- 用于加载js代码 -->
	<!-- /底部 -->
</body>
</html>