<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE HTML>
<html>
<head>
	<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>爱读书</title>
<link rel="shortcut icon" href="favicon.ico">
<link rel="stylesheet" href="/reading/Public/Home/css/themes/default/jquery.mobile-1.4.5.min.css">
<link rel="stylesheet" href="/reading/Public/Home/css/jquery.mobile.structure-1.4.5.min.css" />
<link href="/reading/Public/Home/css/mybook.css" rel="stylesheet" type="text/css" />
<link rel="stylesheet" href="/reading/Public/Home/css/Bootstrap.css" />
<script src="/reading/Public/Home/js/app.js"></script>
<script src="/reading/Public/Home/js/jquery.js"></script>
<script src="/reading/Public/Home/js/jquery.mobile-1.4.5.min.js"></script>
<script type="text/javascript" src="/reading/Public/Home/js/preloader.js"></script>
<script type="text/javascript" src="/reading/Public/Home/js/pdf.worker.js"></script>
<script src="/reading/Public/Home/js/pdf.js"></script>

</head>
<body></block>
	<!-- 主体 -->
	    
<div data-role="page" id="page1">
       <!--header-->
        <div data-role="header" data-position="fixed">
        <h1>习惯养成</h1>
            <a data-rel="back" data-icon="arrow-l" data-theme="a" data-iconpos="notext" data-ajax="false" class="back" >后退</a>        
 			<a href="home.html" data-icon="home" data-theme="a" data-iconpos="notext" data-ajax="false" class="back">查看</a>
         </div>
         
           <!--content-->
<!--进度条 start-->
  <div id="preloader">
    <div id="status">
      <p class="center-text"> <em>请稍等，吐血加载中……<br>
        取决于你的网速!</em> </p>
    </div>
  </div>
  <!--进度条 end--> 
 <div data-role="content">
     <form action="<?php echo U('DailyRead/everydaySign');?>" method="post" data-ajax="false">
     <div>
      <select name="bookid" id="select_week"  data-native-menu="false" >
      	<?php if(is_array($bookn)): $i = 0; $__LIST__ = $bookn;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?><option value="<?php echo ($vo["id"]); ?>">《<?php echo ($vo["bookname"]); ?>》</option><?php endforeach; endif; else: echo "" ;endif; ?>
       </select>
      </div>
    <div class="booklist">
      <select name="select_week" id="select_week"  data-native-menu="false" disabled="true">
        <option value="1">第<?php echo ($totalDays['total_days']+1); ?>天</option>
       </select>
      </div>
      <div class="booklist1">
        <label for="">开始页码</label>
        <input type="text" name="txt_bookAuthor" id="txt_bookAuthor" placeholder="请输入页数" value="开始页码为上次的结束页码" required disabled="true">
      </div>
      <div class="booklist1">
        <label for="">结束页码</label>
        <input type="text" name="page" id="txt_bookAuthor" placeholder="页数不能大于本书的总页数" value="" required>
      </div>
      
      <div class="notes">
         <label for="txt_words">感悟/好文段:</label>
         <textarea   rows="5"   name="content" id="txt_words" placeholder="请输入你的感悟或者摘录好文段"   required></textarea>
     </div>
      <input type="submit" value="每日签到" data-theme="e" >
      <a href="<?php echo U('showSign');?>" class="ui-btn ui-shadow ui-corner-all ui-btn-f" data-ajax="false">签到情况</a>
    </div>


     
  </div><!--/demo-html -->
</form>
</div>
         
         
            <!--footer-->    
 <div data-role="footer" data-position="fixed" data-tap-toggle="false" class="jqm-footer">
      <p style="margin-bottom:0;line-height:24px;color:#fff;">珠海一职语文课外阅读研究课题组</p>
      <p style="margin-top:0;margin-bottom:0;line-height:20px;font-size:0.7em;">一职悦读吧 </p>
</div>
    </div>

 
    <div data-role="page" id="page2"  data-dialog="true">

        <div data-role="header" data-theme="a">
            <h1>选择书本信息</h1>
        </div>

        <div role="main" class="ui-content">
            <h3>选择你以前录入的书本信息</h3>
            <fieldset data-role="controlgroup">
                <legend>Vertical:</legend>
                <input type="radio" name="radio-choice-v-2" id="radio-choice-v-2a" value="on" checked="checked">
                <label for="radio-choice-v-2a">One</label>
                <input type="radio" name="radio-choice-v-2" id="radio-choice-v-2b" value="off">
                <label for="radio-choice-v-2b">Two</label>
                <input type="radio" name="radio-choice-v-2" id="radio-choice-v-2c" value="other">
                <label for="radio-choice-v-2c">Three</label>
            </fieldset>
            <a href="index.html" data-rel="back" class="ui-btn ui-shadow ui-corner-all ui-btn-a">选取</a>
            <a href="index.html" data-rel="back" class="ui-btn ui-shadow ui-corner-all ui-btn-a">关闭</a>
        </div>
         
        </div> 

	<!-- /主体 -->

	<!-- 底部 -->
	 <!-- 用于加载js代码 -->
	<!-- /底部 -->
</body>
</html>