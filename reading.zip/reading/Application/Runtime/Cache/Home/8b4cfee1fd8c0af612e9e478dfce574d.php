<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE HTML>
<html>
<head>
	<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>爱读书</title>
<link rel="shortcut icon" href="favicon.ico">
<link rel="stylesheet" href="/reading/Public/Home/css/themes/default/jquery.mobile-1.4.5.min.css">
<link rel="stylesheet" href="/reading/Public/Home/css/jquery.mobile.structure-1.4.5.min.css" />
<link href="/reading/Public/Home/css/mybook.css" rel="stylesheet" type="text/css" />
<link rel="stylesheet" href="/reading/Public/Home/css/Bootstrap.css" />
<script src="/reading/Public/Home/js/app.js"></script>
<script src="/reading/Public/Home/js/jquery.js"></script>
<script src="/reading/Public/Home/js/jquery.mobile-1.4.5.min.js"></script>
<script type="text/javascript" src="/reading/Public/Home/js/preloader.js"></script>
<script type="text/javascript" src="/reading/Public/Home/js/pdf.worker.js"></script>
<script src="/reading/Public/Home/js/pdf.js"></script>

</head>
<body></block>
	<!-- 主体 -->
	
  <div data-role="page" id="page1">
       <!--header-->
        <div data-role="header" data-position="fixed">
        <h1>本周计划</h1>
            <a href="<?php echo U('Index/index');?>" data-icon="arrow-l" data-theme="a" data-iconpos="notext" data-ajax="false" class="back" >后退</a>
            <a href="<?php echo U('Index/index');?>" data-icon="home" data-theme="a" data-iconpos="notext" data-ajax="false" class="back">后退</a>

         </div>
         
           <!--content-->
<!--进度条 start-->
  <div id="preloader">
    <div id="status">
      <p class="center-text"> <em>请稍等，吐血加载中……<br>
        取决于你的网速!</em> </p>
    </div>
  </div>
  <!--进度条 end--> 
<div data-role="content">
  <form action="<?php echo U('WeeklySchedule/add');?>" method="post" data-ajax="false">
    <h2 class="title2">填写计划信息</h2>
    <div>
      <select name="bookid" id="select_week"  data-native-menu="false">
	      <?php if(is_array($data)): $i = 0; $__LIST__ = $data;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?><option value="<?php echo ($vo["id"]); ?>" class="option_num">《<?php echo ($vo["bookname"]); ?>》</option><?php endforeach; endif; else: echo "" ;endif; ?>
      </select>
      </div>
    <div class="booklist">
      <select name="select_week" id="select_week"  data-native-menu="false" disabled="true">
        <option value="">第<?php echo getCycle();?>周</option>
        </select>
      </div>
      <div class="booklist">
        <label for="">页数</label>
        <input type="text" name="planpage" id="txt_bookAuthor" placeholder="计划阅读页数" required>
      </div>
      <div class="booklist">
        <label for="">时间段</label>
        <input type="time" name="readtime" id="txt_bookAuthor" placeholder="阅读时间段例如: 08:00" required>
      </div>
      <input type="submit" value="开始阅读" data-theme="b">
      <a href="<?php echo U('index');?>" class="ui-btn ui-shadow ui-corner-all ui-btn-f" data-ajax="false">查看计划</a>
      
    </div><!--/demo-html -->
  </form>
    <!--footer-->    
 <div data-role="footer" data-position="fixed" data-tap-toggle="false" class="jqm-footer">
      <p style="margin-bottom:0;line-height:24px;color:#fff;">珠海一职语文课外阅读研究课题组</p>
      <p style="margin-top:0;margin-bottom:0;line-height:20px;font-size:0.7em;">一职悦读吧 </p>
</div>
</div>
<script>
	$(function(){
		var option_num = $('.option_num').text();
		if(option_num == ''){
			alert("请填写书本再制定计划！\n点击确定后跳转至首页");
			window.location.href='<?php echo U('Index/index');?>';
		}
	})
</script>

	<!-- /主体 -->

	<!-- 底部 -->
	 <!-- 用于加载js代码 -->
	<!-- /底部 -->
</body>
</html>