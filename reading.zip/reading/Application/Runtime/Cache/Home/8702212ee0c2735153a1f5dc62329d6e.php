<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE HTML>
<html>
<head>
	<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>爱读书</title>
<link rel="shortcut icon" href="favicon.ico">
<link rel="stylesheet" href="/reading/Public/Home/css/themes/default/jquery.mobile-1.4.5.min.css">
<link rel="stylesheet" href="/reading/Public/Home/css/jquery.mobile.structure-1.4.5.min.css" />
<link href="/reading/Public/Home/css/mybook.css" rel="stylesheet" type="text/css" />
<link rel="stylesheet" href="/reading/Public/Home/css/Bootstrap.css" />
<script src="/reading/Public/Home/js/app.js"></script>
<script src="/reading/Public/Home/js/jquery.js"></script>
<script src="/reading/Public/Home/js/jquery.mobile-1.4.5.min.js"></script>
<script type="text/javascript" src="/reading/Public/Home/js/preloader.js"></script>
<script type="text/javascript" src="/reading/Public/Home/js/pdf.worker.js"></script>
<script src="/reading/Public/Home/js/pdf.js"></script>

</head>
<body></block>
	<!-- 主体 -->
	  	
<div data-role="page" id="page1">
       <!--header-->
        <div data-role="header" data-position="fixed">
        <h1>每天读书</h1>
            <a data-rel="back" data-icon="arrow-l" data-theme="a" data-iconpos="notext" data-ajax="false"  class="back">后退</a>
            <a href="home.html" data-icon="home" data-theme="a" data-iconpos="notext" data-ajax="false" class="back">查看</a>
         </div>
         
           <!--content-->
<!--进度条 start-->
  <div id="preloader">
    <div id="status">
      <p class="center-text"> <em>请稍等，吐血加载中……<br>
        取决于你的网速!</em> </p>
    </div>
  </div>
  <!--进度条 end-->
  <div data-role="navbar">
    <ul class="day">
      <li><a href="#" data-icon="star" data-rel="popup"><span><?php echo get_score();?></span>积分</a></li>
      <li><a href="<?php echo U('rule');?>" data-icon="info" data-ajax="false">积分规则</a></li>
    </ul>
  </div>
  <div data-role="content">
    <form action="#" method="post" data-ajax="false">
       <?php if(is_array($ws)): $i = 0; $__LIST__ = $ws;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?><div class="ui-content success_content ui-corner-all ui-shadow ui-overlay-shadow">
		        <p>书名: <span>《<?php echo getBookName($vo['bookid']);?>》</span></p>
		        <p>当天/这周计划阅读页数: <span><?php echo getNowPage($vo['bookid']);?>/<?php echo ($vo["planpage"]); ?></span></p>
		        <p>书本总页数:<span><?php echo getBookPage($vo['bookid']);?></span></p>
		        <p>当天阅读笔记字数:<span><?php echo getNowNotes($vo['bookid']);?></span></p>
		        <p>积累阅读笔记字数:<span><?php echo ($sum_notes_amount); ?></span></p>
		     </div><?php endforeach; endif; else: echo "" ;endif; ?>
     <div class="success_btn">
        <a href="<?php echo U('DailyRead/everydaySign');?>" class="ui-btn ui-shadow ui-corner-all ui-btn-e" data-ajax="false">读书签到</a>
      </div>
      <div class="success_btn">
        <a href="<?php echo U('DailyRead/showsign');?>" class="ui-btn ui-shadow ui-corner-all ui-btn-e" data-ajax="false">读书笔记</a>
      </div>
      <div class="success_btn">
        <a href="<?php echo U('Statistics/index');?>" class="ui-btn ui-shadow ui-corner-all ui-btn-f" data-ajax="false">每周积分排行榜</a>
      </div>
    </form>
  </div> 
        <!--footer-->    
 <div data-role="footer" data-position="fixed" data-tap-toggle="false" class="jqm-footer">
      <p style="margin-bottom:0;line-height:24px;color:#fff;">珠海一职语文课外阅读研究课题组</p>
      <p style="margin-top:0;margin-bottom:0;line-height:20px;font-size:0.7em;">一职悦读吧 </p>
</div>
</div>

 
    <div data-role="page" id="page2"  data-dialog="true">

        <div data-role="header" data-theme="a">
            <h1>选择书本信息</h1>
        </div>

        <div role="main" class="ui-content">
            <h3>选择你以前录入的书本信息</h3>
            <fieldset data-role="controlgroup">
                <legend>Vertical:</legend>
                <input type="radio" name="radio-choice-v-2" id="radio-choice-v-2a" value="on" checked="checked">
                <label for="radio-choice-v-2a">One</label>
                <input type="radio" name="radio-choice-v-2" id="radio-choice-v-2b" value="off">
                <label for="radio-choice-v-2b">Two</label>
                <input type="radio" name="radio-choice-v-2" id="radio-choice-v-2c" value="other">
                <label for="radio-choice-v-2c">Three</label>
            </fieldset>
            <a href="index.html" data-rel="back" class="ui-btn ui-shadow ui-corner-all ui-btn-a">选取</a>
            <a href="index.html" data-rel="back" class="ui-btn ui-shadow ui-corner-all ui-btn-a">关闭</a>
        </div>
</div> 

	<!-- /主体 -->

	<!-- 底部 -->
	 <!-- 用于加载js代码 -->
	<!-- /底部 -->
</body>
</html>