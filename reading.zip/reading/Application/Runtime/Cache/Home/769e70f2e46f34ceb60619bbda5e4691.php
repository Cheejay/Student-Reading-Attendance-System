<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE HTML>
<html>
<head>
	<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>爱读书</title>
<link rel="shortcut icon" href="favicon.ico">
<link rel="stylesheet" href="/reading/Public/Home/css/themes/default/jquery.mobile-1.4.5.min.css">
<link rel="stylesheet" href="/reading/Public/Home/css/jquery.mobile.structure-1.4.5.min.css" />
<link href="/reading/Public/Home/css/mybook.css" rel="stylesheet" type="text/css" />
<link rel="stylesheet" href="/reading/Public/Home/css/Bootstrap.css" />
<script src="/reading/Public/Home/js/app.js"></script>
<script src="/reading/Public/Home/js/jquery.js"></script>
<script src="/reading/Public/Home/js/jquery.mobile-1.4.5.min.js"></script>
<script type="text/javascript" src="/reading/Public/Home/js/preloader.js"></script>
<script type="text/javascript" src="/reading/Public/Home/js/pdf.worker.js"></script>
<script src="/reading/Public/Home/js/pdf.js"></script>

</head>
<body></block>
	<!-- 主体 -->
	
<div data-role="page" data-theme="a">
        <!--header-->
        <div data-role="header">
            <a href="<?php echo U('Public/logout');?>" data-role="button" data-icon="delete" data-iconpos="notext" class="back"data-ajax="false">退出</a>
            <h3>一职悦读吧</h3>
            <div class="banner">
                <img src="/reading/Public/Home/images/school.jpg" alt="">
            </div>
        </div>

<!--content-->
<!--进度条 start-->
  <div id="preloader">
    <div id="status">
      <p class="center-text"> <em>请稍等，吐血加载中……<br>
        取决于你的网速!</em> </p>
    </div>
  </div>
<!--进度条 end--> 
        <div data-role="content" style="margin-bottom:3rem;">
            <div class="userInfo">欢迎您&nbsp;<?php echo $sinfo['nickname'];?>(<?php echo $sinfo['studentid'];?>)
            <a href="<?php echo U('User/index');?>" class="update fr" data-ajax="false"><!-- 个人信息 --></a>
            </div>
            <!-- 星级评价start -->
            <div class="star">
                <p>
                    您当前的积分：<span class="integral"><?php echo get_score();?></span>
                </p>
                <div class="star_span">
                    <span class="label">星级：</span>
                    <!-- 激活状态 star_active -->
                    <span class="star_list"></span>
                    <span class="star_list"></span>
                    <span class="star_list"></span>
                    <span class="star_list"></span>
                    <span class="star_list"></span>
                    <div class="clear"></div>
                </div>
                <div class="medal_span">
                    <span class="label">勋章：</span>
                    <!-- 激活状态 star_active -->
                    <span class="medal_list"></span>
                    <span class="medal_list"></span>
                    <span class="medal_list"></span>
                    <div class="clear"></div>

                </div>   
            </div> 
            <div class="info">
                <p>当前排名：<span class=""><?php echo ((isset($ranking) && ($ranking !== ""))?($ranking):0); ?></span></p>
            </div>
            <div class="clear"></div>
            <!-- 星级评价end -->
            <div class="ui-grid-b h20" >
                <div class="ui-block-a mycenter">
                    <a class="homeIcon" href="<?php echo U('Book/index');?>" data-ajax="false"><img src="/reading/Public/Home/images/icon26.png" class="img1"> <p>我的书单</p></a>
                </div>
                <div class="ui-block-b mycenter"> 
                    <a class="homeIcon" href="<?php echo U('WeeklySchedule/add');?>" data-ajax="false"><img src="/reading/Public/Home/images/iconB02.jpg" class="img1"> <p>本周计划</p>
                    </a>
                </div>
                <div class="ui-block-c mycenter">
                    <a class="homeIcon" href="<?php echo U('DailyRead/index');?>" data-ajax="false" ><img src="/reading/Public/Home/images/iconB06.jpg" class="img1"> <p>读书签到</p>
                    </a>
                </div>
                <div class="ui-block-a mycenter">
                    <a class="homeIcon" href="<?php echo U('News/book');?>" data-ajax="false"><img src="/reading/Public/Home/images/iconB05.jpg" class="img1"> <p>好书推荐</p>
                    </a>
                </div>
                <div class="ui-block-b mycenter"> 
                    <a class="homeIcon" href="<?php echo U('Statistics/index');?>" data-ajax="false"><img src="/reading/Public/Home/images/iconB01.jpg" class="img1"> <p>每周排行</p>
                    </a>
                </div>

                <div class="ui-block-c mycenter">
                    <a class="homeIcon" href="<?php echo U('News/notice');?>" data-ajax="false" ><img src="/reading/Public/Home/images/iconB04.jpg" class="img1"> <p>悦读论坛</p>
                    </a>        
                 </div>
            </div>
        </div>
     	<!--footer-->    
 <div data-role="footer" data-position="fixed" data-tap-toggle="false" class="jqm-footer">
      <p style="margin-bottom:0;line-height:24px;color:#fff;">珠海一职语文课外阅读研究课题组</p>
      <p style="margin-top:0;margin-bottom:0;line-height:20px;font-size:0.7em;">一职悦读吧 </p>
</div>
     	
        <div class="showDiaLogImg">
        </div>
</div>

	<!-- /主体 -->

	<!-- 底部 -->
	
	<script>
		credit();
		<?php if(session('tx') == 0): ?>showDiaLog();
			<?php echo session('tx',1); endif; ?>		
	</script>
 <!-- 用于加载js代码 -->
	<!-- /底部 -->
</body>
</html>