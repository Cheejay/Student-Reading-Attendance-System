<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE HTML>
<html>
<head>
	<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>爱读书</title>
<link rel="shortcut icon" href="favicon.ico">
<link rel="stylesheet" href="/reading/Public/Home/css/themes/default/jquery.mobile-1.4.5.min.css">
<link rel="stylesheet" href="/reading/Public/Home/css/jquery.mobile.structure-1.4.5.min.css" />
<link href="/reading/Public/Home/css/mybook.css" rel="stylesheet" type="text/css" />
<link rel="stylesheet" href="/reading/Public/Home/css/Bootstrap.css" />
<script src="/reading/Public/Home/js/app.js"></script>
<script src="/reading/Public/Home/js/jquery.js"></script>
<script src="/reading/Public/Home/js/jquery.mobile-1.4.5.min.js"></script>
<script type="text/javascript" src="/reading/Public/Home/js/preloader.js"></script>
<script type="text/javascript" src="/reading/Public/Home/js/pdf.worker.js"></script>
<script src="/reading/Public/Home/js/pdf.js"></script>

</head>
<body></block>
	<!-- 主体 -->
	  	
<div data-role="page" id="page1">
 <!--header-->
  <div data-role="header" data-position="fixed">
    <h1></h1>
      <a href="<?php echo U('everydaySign');?>" data-icon="arrow-l" data-theme="a" data-iconpos="notext" data-ajax="false" class="back" >后退</a>
      <a href="<?php echo U('Index/index');?>" data-icon="home" data-theme="a" data-iconpos="notext" data-ajax="false" class="back">查看</a>
    </div>

    <div data-role="content" class="h50">
      <div class="ui-grid-a success">
        <div class="ui-block-c">
          <img src="/reading/Public/Home/images/cg.png "width="40" height="40" alt="">
        </div>
        <div class="ui-block-d">
          <p>连续签到<?php echo ((isset($days["continuous_sign_days"]) && ($days["continuous_sign_days"] !== ""))?($days["continuous_sign_days"]):0); ?>天成功！</p>
        </div>
        <div class="ui-block-d">
        	<?php $score=$days['continuous_sign_days']*10; ?>
          <p>获得<?php echo ($score); ?>积分!</p>
        </div>      
       
      </div>
      <?php $sc = get_score(); $sumsc = 300 - $sc; ?>
      <?php if($sc < 300): ?><h4 class="success_text">加油！您还差<?php echo ($sumsc); ?>积分可以获得一个勋章!</h4><?php endif; ?>
      
      <ul data-role="listview" data-inset="true" class="reading">
      	<?php if(is_array($Signdata)): $i = 0; $__LIST__ = $Signdata;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?><li>
		        <div class="ui-block-c">
		          
		          <h3><?php echo session('user_auth.nickname');?> <span class="time"><?php echo ($vo["sign_time"]); ?></span></h3>
		           《<?php echo getBookName($vo['bookid']);?>》<span class="time"><?php echo ($vo["startpage"]); ?>-<?php echo ($vo["stoppage"]); ?></span>
		           <span><a href="<?php echo U('showNotes',array('id'=>$vo['id']));?>" data-ajax="false">查看笔记</a></span>
		        </div>
		      
		        <span class="ui-li-count">签到:<?php echo ($vo["sign_days"]); ?>天</span>
		       
		      </li><?php endforeach; endif; else: echo "" ;endif; ?>
    </ul>
    <div class="success_btn">
        <a href="<?php echo U('Index/index');?>" class="ui-btn ui-shadow ui-corner-all ui-btn-e" data-ajax="false">返回首页</a>
      </div>
   
  <!--footer-->    
 <div data-role="footer" data-position="fixed" data-tap-toggle="false" class="jqm-footer">
      <p style="margin-bottom:0;line-height:24px;color:#fff;">珠海一职语文课外阅读研究课题组</p>
      <p style="margin-top:0;margin-bottom:0;line-height:20px;font-size:0.7em;">一职悦读吧 </p>
</div>
</div> 

	<!-- /主体 -->

	<!-- 底部 -->
	 <!-- 用于加载js代码 -->
	<!-- /底部 -->
</body>
</html>