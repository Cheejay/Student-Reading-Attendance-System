<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE HTML>
<html>
<head>
	<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>爱读书</title>
<link rel="shortcut icon" href="favicon.ico">
<link rel="stylesheet" href="/reading/Public/Home/css/themes/default/jquery.mobile-1.4.5.min.css">
<link rel="stylesheet" href="/reading/Public/Home/css/jquery.mobile.structure-1.4.5.min.css" />
<link href="/reading/Public/Home/css/mybook.css" rel="stylesheet" type="text/css" />
<link rel="stylesheet" href="/reading/Public/Home/css/Bootstrap.css" />
<script src="/reading/Public/Home/js/app.js"></script>
<script src="/reading/Public/Home/js/jquery.js"></script>
<script src="/reading/Public/Home/js/jquery.mobile-1.4.5.min.js"></script>
<script type="text/javascript" src="/reading/Public/Home/js/preloader.js"></script>
<script type="text/javascript" src="/reading/Public/Home/js/pdf.worker.js"></script>
<script src="/reading/Public/Home/js/pdf.js"></script>

</head>
<body></block>
	<!-- 主体 -->
	

      
   <div data-role="page" id="page1">
       <!--header-->
        <div data-role="header" data-position="fixed">
        <h1>查看书单</h1>
            <a href="<?php echo U('index');?>" data-icon="arrow-l" data-theme="a" data-iconpos="notext" data-ajax="false" class="back" >后退</a>
            <a href="<?php echo U('Index/index');?>" data-icon="home" data-theme="a" data-iconpos="notext" data-ajax="false" class="back">查看</a>
         </div>
         
           <!--content-->
<!--进度条 start-->
  <div id="preloader">
    <div id="status">
      <p class="center-text"> <em>请稍等，吐血加载中……<br>
        取决于你的网速!</em> </p>
    </div>
  </div>
  <!--进度条 end--> 
<div data-role="content">
    <form action="#" method="post">
      <div data-role="main" class="ui-content">
        <div class="bookShow">
          <div data-role="collapsible">
            <h1>未开始阅读<span class="fr"><?php echo ($data["wyd"]); ?>本</span></h1>
            <ul data-role="listview" data-inset="true">
             <?php if(is_array($wyd)): $i = 0; $__LIST__ = $wyd;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?><li>
                <a href="#">
                <p>书名: <span>《<?php echo ($vo["bookname"]); ?>》</span></p>
                <p>作者: <span><?php echo ($vo["author"]); ?></span></p>  
                <p>页数:<span><?php echo ($vo["bookpage"]); ?></span></p>
                <p>出版社:<span><?php echo ($vo["press"]); ?></span></p>
                </a>
                <a href="<?php echo U('delete',array('id'=>$vo['id']));?>" class="ui-btn ui-icon-delete ui-btn-icon-left" data-ajax="false" onclick="return firm()">>文本信息</a>
              </li><?php endforeach; endif; else: echo "" ;endif; ?>
            </ul>
        </div>
         <div data-role="collapsible">
            <h1>正在阅读<span class="fr"><?php echo ($data["zyd"]); ?>本</span></h1>
            <ul data-role="listview" data-inset="true">
            <?php if(is_array($zyd)): $i = 0; $__LIST__ = $zyd;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?><li>
                <a href="#">
                <p>书名: <span>《<?php echo ($vo["bookname"]); ?>》</span></p>
                <p>作者: <span><?php echo ($vo["author"]); ?></span></p>  
                <p>页数:<span><?php echo ($vo["bookpage"]); ?></span></p>
                <p>出版社:<span><?php echo ($vo["press"]); ?></span></p>
                </a>
                <a href="<?php echo U('delete',array('id'=>$vo['id']));?>" class="ui-btn ui-icon-delete ui-btn-icon-left" data-ajax="false" onclick="return firm()">>文本信息</a>
              </li><?php endforeach; endif; else: echo "" ;endif; ?>
            </ul>
        </div>
         <div data-role="collapsible">
         
            <h1>完成阅读<span class="fr"><?php echo ($data["yyd"]); ?>本</span></h1>
            <ul data-role="listview" data-inset="true">
            <?php if(is_array($yyd)): $i = 0; $__LIST__ = $yyd;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?><li>
                <a href="#">
                <p>书名: <span>《<?php echo ($vo["bookname"]); ?>》</span></p>
                <p>作者: <span><?php echo ($vo["author"]); ?></span></p>  
                <p>页数:<span><?php echo ($vo["bookpage"]); ?></span></p>
                <p>出版社:<span><?php echo ($vo["press"]); ?></span></p>
                </a>
                <a href="<?php echo U('delete',array('id'=>$vo['id']));?>" class="ui-btn ui-icon-delete ui-btn-icon-left" data-ajax="false" onclick="return firm()">>文本信息</a>
              </li><?php endforeach; endif; else: echo "" ;endif; ?>
            </ul>
        </div>
        </div>
      </div>
    </form>
    <div class="success_btn">
        <a href="<?php echo U('index');?>" class="ui-btn ui-shadow ui-corner-all ui-btn-e" data-ajax="false">继续添加</a>
      </div>
    <div class="success_btn">
       <a href="<?php echo U('share_books');?>" class="ui-btn ui-shadow ui-corner-all ui-btn-f" data-ajax="false">晒书单</a>
     </div>
         <!--footer-->    
 <div data-role="footer" data-position="fixed" data-tap-toggle="false" class="jqm-footer">
      <p style="margin-bottom:0;line-height:24px;color:#fff;">珠海一职语文课外阅读研究课题组</p>
      <p style="margin-top:0;margin-bottom:0;line-height:20px;font-size:0.7em;">一职悦读吧 </p>
</div>
    </div>

	<!-- /主体 -->

	<!-- 底部 -->
	

<script>
function firm(e)

{
        //利用对话框返回的值 （true 或者 false）
 
    return confirm("是否要删除？");
 
}
</script>

 <!-- 用于加载js代码 -->
	<!-- /底部 -->
</body>
</html>