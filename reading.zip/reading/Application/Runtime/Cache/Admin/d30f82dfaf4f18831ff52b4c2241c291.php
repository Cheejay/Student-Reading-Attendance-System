<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />

<!-- Required Stylesheets -->
<link rel="stylesheet" type="text/css" href="/reading/Public/Admin/css/reset.css" media="screen" />
<link rel="stylesheet" type="text/css" href="/reading/Public/Admin/css/text.css" media="screen" />
<link rel="stylesheet" type="text/css" href="/reading/Public/Admin/css/fonts/ptsans/stylesheet.css" media="screen" />
<link rel="stylesheet" type="text/css" href="/reading/Public/Admin/css/fluid.css" media="screen" />

<link rel="stylesheet" type="text/css" href="/reading/Public/Admin/css/mws.style.css" media="screen" />
<link rel="stylesheet" type="text/css" href="/reading/Public/Admin/css/icons/icons.css" media="screen" />

<!-- Demo and Plugin Stylesheets -->
<link rel="stylesheet" type="text/css" href="/reading/Public/Admin/css/demo.css" media="screen" />
<link rel="stylesheet" type="text/css" href="/reading/Public/Admin/css/jui/jquery.ui.css" media="screen" />
<!-- Theme Stylesheet -->
<link rel="stylesheet" type="text/css" href="/reading/Public/Admin/css/mws.theme.css" media="screen" />
<!-- JavaScript /reading/public/Adminplugins -->
<script type="text/javascript" src="/reading/Public/Admin/js/jquery-1.7.1.min.js"></script>
<!--[if lt IE 9]>
<script type="text/javascript" src="/reading/public/Adminplugins/flot/excanvas.min.js"></script>
<![endif]-->

<script type="text/javascript" src="/reading/Public/Admin/js/jquery-ui.js"></script>
<script type="text/javascript" src="/reading/Public/Admin/js/mws.js"></script>
<script type="text/javascript">
	$(document).ready(function() {
		$("div#mws-login .mws-login-back").mouseover(function(event) {
			$(this).find("a").animate({'left':0})
		}).mouseout(function(event) {
			$(this).find("a").animate({'left':70})
		});
	});
</script>
<title>珠海一职悦读吧</title>
</head>
<body>
	<div id="mws-login">
    	<h1>一职悦读吧后台管理系统</h1>
    	<div id="mws-login-form">
        	<form class="mws-form" action="<?php echo U('login');?>" method="post">
                <div class="mws-form-row">
                	<div class="mws-form-item large">
                    	<input type="text" name='username' class="mws-login-username mws-textinput" placeholder="username" />
                    </div>
                </div>
                <div class="mws-form-row">
                	<div class="mws-form-item large">
                    	<input type="password" name='password' class="mws-login-password mws-textinput" placeholder="password" />
                    </div>
                </div>
                <div class="mws-form-row">
                	<input type="submit" value="Login" class="mws-button green mws-login-button" />
                </div>
            </form>
        </div>
    </div>
</body>
</html>