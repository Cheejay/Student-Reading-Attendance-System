<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />

    <!-- Required Stylesheets -->
    <link rel="stylesheet" type="text/css" href="/reading/Public/Admin/css/reset.css" media="screen" />
    <link rel="stylesheet" type="text/css" href="/reading/Public/Admin/css/text.css" media="screen" />
    <link rel="stylesheet" type="text/css" href="/reading/Public/Admin/css/fonts/ptsans/stylesheet.css" media="screen" />
    <link rel="stylesheet" type="text/css" href="/reading/Public/Admin/css/fluid.css" media="screen" />
    <link rel="stylesheet" type="text/css" href="/reading/Public/Admin/css/mws.style.css" media="screen" />
    <link rel="stylesheet" type="text/css" href="/reading/Public/Admin/css/icons/icons.css" media="screen" />
    <!-- Theme Stylesheet -->
    <link rel="stylesheet" type="text/css" href="/reading/Public/Admin/css/mws.theme.css" media="screen" />
    <!-- JavaScript Plugins -->
    <script type="text/javascript" src="/reading/Public/Admin/js/jquery-1.7.1.min.js"></script>
    <script type="text/javascript" src="/reading/Public/Admin/plugins/jquery.filestyle.js"></script>
    <script type="text/javascript" src="/reading/Public/Admin/js/mws.js"></script>


	
    <script type="text/javascript" charset="utf-8" src="/reading/Public/Admin/ueditor/ueditor.config.js"></script>
    <script type="text/javascript" charset="utf-8" src="/reading/Public/Admin/ueditor/ueditor.all.min.js"> </script>
    <!--建议手动加在语言，避免在ie下有时因为加载语言失败导致编辑器加载失败-->
    <!--这里加载的语言文件会覆盖你在配置项目里添加的语言类型，比如你在配置项目里配置的是英文，这里加载的中文，那最后就是中文-->
    <script type="text/javascript" charset="utf-8" src="/reading/Public/Admin/ueditor/lang/zh-cn/zh-cn.js"></script>

    <title>珠海一职读书吧</title>

</head>

<body>
<!-- Header Wrapper -->
<div id="mws-header" class="clearfix">
    <!-- Logo Wrapper -->
    <div id="mws-logo-container">
        <div id="mws-logo-wrap">
            <img src="/reading/Public/Admin/images/mws-logo.png" alt="mws admin" />
        </div>
    </div>

    <!-- User Area Wrapper -->
    <div id="mws-user-tools" class="clearfix">

        <!-- User Functions -->
        <div id="mws-user-info" class="mws-inset">
            <div id="mws-user-photo">
                <img src="/reading/Public/Admin/example/profile.jpg" alt="User Photo" />
            </div>
            <div id="mws-user-functions">
                <div id="mws-username">
                   <?php echo session('user_auth.username');?>
                </div>
                <ul>
                    <li><a href="<?php echo U('Public/logout');?>">退出登录</a></li>
                </ul>
            </div>
        </div>
        <!-- End User Functions -->

    </div>
</div>

<!-- Main Wrapper -->
<div id="mws-wrapper">
    <!-- Necessary markup, do not remove -->
    <div id="mws-sidebar-stitch"></div>
    <div id="mws-sidebar-bg"></div>

    <!-- Sidebar Wrapper -->
    <div id="mws-sidebar">

        <!-- Search Box -->


        <!-- Main Navigation -->
        <div id="mws-navigation">
            <ul>
                <li class="active"><a href="<?php echo U('Index/index');?>" class="mws-i-24 i-table-1">全校每周数据</a></li>
                <li><a href="<?php echo U('Index/class_week');?>" class="mws-i-24 i-table-1">班级每周数据</a></li>
                <li><a href="<?php echo U('Book/hot');?>" class="mws-i-24 i-book-large">热门书籍</a></li>
                <li><a href="<?php echo U('News/index',array('type'=>0));?>" class="mws-i-24 i-book-large">好书推荐</a></li>
                <li><a href="<?php echo U('News/index',array('type'=>2));?>" class="mws-i-24 i-book-large">在线阅读</a></li>
                <li><a href="<?php echo U('News/index',array('type'=>1));?>" class="mws-i-24 i-speech-bubble-2">通知信息</a></li>
                <li><a href="<?php echo U('News/share');?>" class="mws-i-24 i-speech-bubble-2">审核分享</a></li>
                <li><a href="<?php echo U('Student/index');?>" class="mws-i-24 i-users-2">学生资料</a></li>
                <li><a href="<?php echo U('User/index');?>" class="mws-i-24 i-admin-user-2">管理员管理</a></li>
                <li><a href="<?php echo U('System/index');?>" class="mws-i-24 i-admin-user-2">系统配置</a></li>
            </ul>
        </div>
        <!-- End Navigation -->

    </div>

    <!-- Container Wrapper -->
    <div id="mws-container" class="clearfix">
	<!-- Main Container -->
	<div class="container">
		<div class="mws-panel grid_8 mws-collapsible">
			<div class="mws-panel-header">
				<span class="mws-i-24 i-table-1">每周个人数据统计（香华校区）</span>
			</div>
			<div class="mws-panel-body" style="display:none;">
				<table class="mws-table">
					<thead>
					<tr>
						<th>班级</th>
						<th>姓名</th>
						<th>制定计划次数</th>
						<th>读书签到天数</th>
						<th>已阅读书本</th>
						<th>读书笔记字数</th>
						<th>累计积分</th>
						<th>积分排行</th>
					</tr>
					</thead>
					<tbody>
					<?php if(empty($person_branch)): ?><tr><td>暂无数据!</td></tr><?php endif; ?>
					<?php if(is_array($person_branch)): foreach($person_branch as $i=>$vo): ?><tr class="gradeX">
							<td><?php echo ($vo['classid']); ?></td>
							<td><?php echo ($vo['nickname']); ?></td>
							<td><?php echo ((isset($vo['sum_ws']) && ($vo['sum_ws'] !== ""))?($vo['sum_ws']):0); ?></td>
							<td><?php echo ((isset($vo['total_days']) && ($vo['total_days'] !== ""))?($vo['total_days']):0); ?></td>
							<td><a href="<?php echo U('Book/studentBook',array('studentid'=>$vo['studentid']));?>"><?php echo ((isset($vo['complete_read']) && ($vo['complete_read'] !== ""))?($vo['complete_read']):0); ?></a></td>
							<td><?php echo ((isset($vo['sum_notes_amount']) && ($vo['sum_notes_amount'] !== ""))?($vo['sum_notes_amount']):0); ?></td>
							<td><?php echo ($vo['score']); ?></td>
							<td><?php echo $i+1; ?></td>
						</tr><?php endforeach; endif; ?>
					</tbody>
				</table>
			</div>
		</div>
		<div class="mws-panel grid_8 mws-collapsible">
			<div class="mws-panel-header">
				<span class="mws-i-24 i-table-1">每周个人数据统计（主校区）</span>
			</div>
			<div class="mws-panel-body" style="display:none;">
				<table class="mws-table">
					<thead>
					<tr>
						<th>班级</th>
						<th>姓名</th>
						<th>制定计划次数</th>
						<th>读书签到天数</th>
						<th>已阅读书本</th>
						<th>读书笔记字数</th>
						<th>累计积分</th>
						<th>积分排行</th>
					</tr>
					</thead>
					<tbody>
					<?php if(empty($person_main)): ?><tr><td>暂无数据!</td></tr><?php endif; ?>
					<?php if(is_array($person_main)): foreach($person_main as $i=>$vo): ?><tr class="gradeX">
							<td><?php echo ($vo['classid']); ?></td>
							<td><?php echo ($vo['nickname']); ?></td>
							<td><?php echo ((isset($vo['sum_ws']) && ($vo['sum_ws'] !== ""))?($vo['sum_ws']):0); ?></td>
							<td><?php echo ((isset($vo['total_days']) && ($vo['total_days'] !== ""))?($vo['total_days']):0); ?></td>
							<td><a href="<?php echo U('Book/studentBook',array('studentid'=>$vo['studentid']));?>"><?php echo ((isset($vo['complete_read']) && ($vo['complete_read'] !== ""))?($vo['complete_read']):0); ?></a></td>
							<td><?php echo ((isset($vo['sum_notes_amount']) && ($vo['sum_notes_amount'] !== ""))?($vo['sum_notes_amount']):0); ?></td>
							<td><?php echo ($vo['score']); ?></td>
							<td><?php echo $i+1; ?></td>
						</tr><?php endforeach; endif; ?>
					</tbody>
				</table>
			</div>
		</div>
		<div class="mws-panel grid_8 mws-collapsible">
			<div class="mws-panel-header">
				<span class="mws-i-24 i-table-1">每周班级数据统计（香华校区）</span>
			</div>
			<div class="mws-panel-body" style="display:none;">
				<table class="mws-table">
					<thead>
					<tr>
						<th>年级</th>
						<th>班级</th>
						<th>人数</th>
						<th>制定计划次数</th>
						<th>读书签到人数</th>
						<th>已阅读书本</th>
						<th>读书笔记字数</th>
						<th>累计积分</th>
						<th>平均积分</th>
						<th>积分排行</th>
					</tr>
					</thead>
					<tbody>
					<?php if(empty($class_branch)): ?><tr><td>暂无数据!</td></tr><?php endif; ?>
					<?php $total_number=0;$master_plan=0;$total_sign=0;$total_books=0;$general_notes=0;$total_integral=0;$total_average_integral=0; ?>
					<?php if(is_array($class_branch)): foreach($class_branch as $i=>$vo): $total_number = $total_number + $vo['number']; $master_plan = $master_plan + $vo['sum_ws']; $total_sign = $total_sign + $vo['total_days']; $total_books = $total_books + $vo['complete_read']; $general_notes = $general_notes + $vo['sum_notes_amount']; $total_integral = $total_integral + $vo['score']; $total_average_integral = $total_average_integral + $vo['avg_score']; ?>
						<tr class="gradeX">
							<td><?php echo ($vo['grade']); ?></td>
							<td><?php echo ($vo['classid']); ?></td>
							<td><?php echo ($vo['number']); ?></td>
							<td><?php echo ((isset($vo['sum_ws']) && ($vo['sum_ws'] !== ""))?($vo['sum_ws']):0); ?></td>
							<td><?php echo ((isset($vo['total_days']) && ($vo['total_days'] !== ""))?($vo['total_days']):0); ?></td>
							<td><a href="<?php echo U('Book/classBook',array('classid'=>$vo['classid']));?>"><?php echo ((isset($vo['complete_read']) && ($vo['complete_read'] !== ""))?($vo['complete_read']):0); ?></a></td>
							<td><?php echo ((isset($vo['sum_notes_amount']) && ($vo['sum_notes_amount'] !== ""))?($vo['sum_notes_amount']):0); ?></td>
							<td><?php echo ($vo['score']); ?></td>
							<td><?php echo ($vo['avg_score']); ?></td>
							<td><?php echo $i+1; ?></td>
						</tr><?php endforeach; endif; ?>
						<tr class="gradeX">
								<td>总计:</td>
								<td></td>
								<td><?php echo ($total_number); ?></td>
								<td><?php echo ($master_plan); ?></td>
								<td><?php echo ($total_sign); ?></td>
								<td><?php echo ($total_books); ?></a></td>
								<td><?php echo ($general_notes); ?></td>
								<td><?php echo ($total_integral); ?></td>
								<td><?php echo ($total_average_integral); ?></td>
								<td></td>
							</tr>
					</tbody>
				</table>
			</div>
		</div>
		<div class="mws-panel grid_8 mws-collapsible">
			<div class="mws-panel-header">
				<span class="mws-i-24 i-table-1">每周班级数据统计（主校区）</span>
			</div>
			<div class="mws-panel-body" style="display:none;">
				<table class="mws-table">
					<thead>
					<tr>
						<th>年级</th>
						<th>班级</th>
						<th>人数</th>
						<th>制定计划次数</th>
						<th>读书签到人数</th>
						<th>已阅读书本</th>
						<th>读书笔记字数</th>
						<th>累计积分</th>
						<th>平均积分</th>
						<th>积分排行</th>
					</tr>
					</thead>
					<tbody>
					<?php if(empty($class_main)): ?><tr><td>暂无数据!</td></tr><?php endif; ?>
					<?php $total_number=0;$master_plan=0;$total_sign=0;$total_books=0;$general_notes=0;$total_integral=0;$total_average_integral=0; ?>
					<?php if(is_array($class_main)): foreach($class_main as $i=>$vo): $total_number = $total_number + $vo['number']; $master_plan = $master_plan + $vo['sum_ws']; $total_sign = $total_sign + $vo['total_days']; $total_books = $total_books + $vo['complete_read']; $general_notes = $general_notes + $vo['sum_notes_amount']; $total_integral = $total_integral + $vo['score']; $total_average_integral = $total_average_integral + $vo['avg_score']; ?>
						<tr class="gradeX">
							<td><?php echo ($vo['grade']); ?></td>
							<td><?php echo ($vo['classid']); ?></td>
							<td><?php echo ($vo['number']); ?></td>
							<td><?php echo ((isset($vo['sum_ws']) && ($vo['sum_ws'] !== ""))?($vo['sum_ws']):0); ?></td>
							<td><?php echo ((isset($vo['total_days']) && ($vo['total_days'] !== ""))?($vo['total_days']):0); ?></td>
							<td><a href="<?php echo U('Book/classBook',array('classid'=>$vo['classid']));?>"><?php echo ((isset($vo['complete_read']) && ($vo['complete_read'] !== ""))?($vo['complete_read']):0); ?></a></td>
							<td><?php echo ((isset($vo['sum_notes_amount']) && ($vo['sum_notes_amount'] !== ""))?($vo['sum_notes_amount']):0); ?></td>
							<td><?php echo ($vo['score']); ?></td>
							<td><?php echo ($vo['avg_score']); ?></td>
							<td><?php echo $i+1; ?></td>
						</tr><?php endforeach; endif; ?>
						<tr class="gradeX">
							<td>总计:</td>
							<td></td>
							<td><?php echo ($total_number); ?></td>
							<td><?php echo ($master_plan); ?></td>
							<td><?php echo ($total_sign); ?></td>
							<td><?php echo ($total_books); ?></a></td>
							<td><?php echo ($general_notes); ?></td>
							<td><?php echo ($total_integral); ?></td>
							<td><?php echo ($total_average_integral); ?></td>
							<td></td>
							</tr>
					</tbody>
				</table>
			</div>
		</div>
	</div>
	<!-- End Main Container -->
            <!-- Footer -->
            <div id="mws-footer">
                珠海一职悦读吧 &copy;后台管理系统
            </div>
            <!-- End Footer -->

        </div>
        <!-- End Container Wrapper -->

    </div>
    <!-- End Main Wrapper -->  
<script>
function firm(e)

{
        //利用对话框返回的值 （true 或者 false）
 
    return confirm("是否要删除？");
 
}
</script>
</body>
</html>