<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />

    <!-- Required Stylesheets -->
    <link rel="stylesheet" type="text/css" href="/reading/Public/Admin/css/reset.css" media="screen" />
    <link rel="stylesheet" type="text/css" href="/reading/Public/Admin/css/text.css" media="screen" />
    <link rel="stylesheet" type="text/css" href="/reading/Public/Admin/css/fonts/ptsans/stylesheet.css" media="screen" />
    <link rel="stylesheet" type="text/css" href="/reading/Public/Admin/css/fluid.css" media="screen" />
    <link rel="stylesheet" type="text/css" href="/reading/Public/Admin/css/mws.style.css" media="screen" />
    <link rel="stylesheet" type="text/css" href="/reading/Public/Admin/css/icons/icons.css" media="screen" />
    <!-- Theme Stylesheet -->
    <link rel="stylesheet" type="text/css" href="/reading/Public/Admin/css/mws.theme.css" media="screen" />
    <!-- JavaScript Plugins -->
    <script type="text/javascript" src="/reading/Public/Admin/js/jquery-1.7.1.min.js"></script>
    <script type="text/javascript" src="/reading/Public/Admin/plugins/jquery.filestyle.js"></script>
    <script type="text/javascript" src="/reading/Public/Admin/js/mws.js"></script>


	
    <script type="text/javascript" charset="utf-8" src="/reading/Public/Admin/ueditor/ueditor.config.js"></script>
    <script type="text/javascript" charset="utf-8" src="/reading/Public/Admin/ueditor/ueditor.all.min.js"> </script>
    <!--建议手动加在语言，避免在ie下有时因为加载语言失败导致编辑器加载失败-->
    <!--这里加载的语言文件会覆盖你在配置项目里添加的语言类型，比如你在配置项目里配置的是英文，这里加载的中文，那最后就是中文-->
    <script type="text/javascript" charset="utf-8" src="/reading/Public/Admin/ueditor/lang/zh-cn/zh-cn.js"></script>

    <title>珠海一职读书吧</title>

</head>

<body>
<!-- Header Wrapper -->
<div id="mws-header" class="clearfix">
    <!-- Logo Wrapper -->
    <div id="mws-logo-container">
        <div id="mws-logo-wrap">
            <img src="/reading/Public/Admin/images/mws-logo.png" alt="mws admin" />
        </div>
    </div>

    <!-- User Area Wrapper -->
    <div id="mws-user-tools" class="clearfix">

        <!-- User Functions -->
        <div id="mws-user-info" class="mws-inset">
            <div id="mws-user-photo">
                <img src="/reading/Public/Admin/example/profile.jpg" alt="User Photo" />
            </div>
            <div id="mws-user-functions">
                <div id="mws-username">
                   <?php echo session('user_auth.username');?>
                </div>
                <ul>
                    <li><a href="<?php echo U('Public/logout');?>">退出登录</a></li>
                </ul>
            </div>
        </div>
        <!-- End User Functions -->

    </div>
</div>

<!-- Main Wrapper -->
<div id="mws-wrapper">
    <!-- Necessary markup, do not remove -->
    <div id="mws-sidebar-stitch"></div>
    <div id="mws-sidebar-bg"></div>

    <!-- Sidebar Wrapper -->
    <div id="mws-sidebar">

        <!-- Search Box -->


        <!-- Main Navigation -->
        <div id="mws-navigation">
            <ul>
                <li class="active"><a href="<?php echo U('Index/index');?>" class="mws-i-24 i-table-1">全校每周数据</a></li>
                <li><a href="<?php echo U('Index/class_week');?>" class="mws-i-24 i-table-1">班级每周数据</a></li>
                <li><a href="<?php echo U('Book/hot');?>" class="mws-i-24 i-book-large">热门书籍</a></li>
                <li><a href="<?php echo U('News/index',array('type'=>0));?>" class="mws-i-24 i-book-large">好书推荐</a></li>
                <li><a href="<?php echo U('News/index',array('type'=>2));?>" class="mws-i-24 i-book-large">在线阅读</a></li>
                <li><a href="<?php echo U('News/index',array('type'=>1));?>" class="mws-i-24 i-speech-bubble-2">通知信息</a></li>
                <li><a href="<?php echo U('News/share');?>" class="mws-i-24 i-speech-bubble-2">审核分享</a></li>
                <li><a href="<?php echo U('Student/index');?>" class="mws-i-24 i-users-2">学生资料</a></li>
                <li><a href="<?php echo U('User/index');?>" class="mws-i-24 i-admin-user-2">管理员管理</a></li>
                <li><a href="<?php echo U('System/index');?>" class="mws-i-24 i-admin-user-2">系统配置</a></li>
            </ul>
        </div>
        <!-- End Navigation -->

    </div>

    <!-- Container Wrapper -->
    <div id="mws-container" class="clearfix">
    <div class="container">
        <form action="<?php echo U('Student/select');?>" method="post">
            <div class="grid_4">
                <div id="mws-searchbox" class="mws-inset ">
                    <input type="text" name="studentid" class="mws-search-input" placeholder="请输入学生学号查询信息" value="<?php echo ($studentid); ?>"/>
                    <input type="submit" class="mws-search-submit"/>
                </div>
            </div>
        </form>
        <form action="<?php echo U('Student/select');?>" method="post">
            <div class="grid_4">
                <div id="mws-searchbox" class="mws-inset ">
                    <input type="text" name="nickname" class="mws-search-input" placeholder="请输入学生姓名查询信息" value="<?php echo ($nickname); ?>"/>
                    <input type="submit" class="mws-search-submit"/>
                </div>
            </div>
        </form>
        <div class="mws-panel grid_8">
            <div class="mws-panel-header">
                <span class="mws-i-24 i-user-2">修改学生信息</span>
            </div>
            <div class="mws-panel-body">
                <table class="mws-table">
                    <thead>
                    <tr>
                        <th>校区</th>
                        <th>班级</th>
                        <th>姓名</th>
                        <th>性别</th>
                        <th>学号</th>
                        <th>操作</th>
                    </tr>
                    </thead>
                    <tbody>
                    <?php if(empty($list)): ?><tr><td>暂无结果,请输入信息进行搜索！</td></tr><?php endif; ?>
                    <?php if(is_array($list)): foreach($list as $key=>$vo): ?><tr class="gradeX">
                            <td><?php echo ($vo['campus']); ?></td>
                            <td><?php echo ($vo['classid']); ?></td>
                            <td><?php echo ($vo['nickname']); ?></td>
                            <td><?php echo ($vo['sex']); ?></td>
                            <td><?php echo ($vo['studentid']); ?></td>
                            <td>
                                <a href="<?php echo U('password',array('id'=>$vo['id']));?>" class="mws-ic-16 ic-edit pwd_edit">修改密码</a>
                                <?php if($vo['status'] == 1): ?><a href="<?php echo U('status',array('id'=>$vo['id'],'status'=>2));?>" class="mws-ic-16 pwd_edit">禁用</a>
                                <?php else: ?>
                                    <a href="<?php echo U('status',array('id'=>$vo['id'],'status'=>1));?>" class="mws-ic-16 pwd_edit">启用</a><?php endif; ?>
                            </td>
                        </tr><?php endforeach; endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
            <!-- Footer -->
            <div id="mws-footer">
                珠海一职悦读吧 &copy;后台管理系统
            </div>
            <!-- End Footer -->

        </div>
        <!-- End Container Wrapper -->

    </div>
    <!-- End Main Wrapper -->  
<script>
function firm(e)

{
        //利用对话框返回的值 （true 或者 false）
 
    return confirm("是否要删除？");
 
}
</script>
</body>
</html>