<?php
namespace User\Model;
use Think\Model;
/*  学生模型  */
class MemberModel extends Model{
	/**
	 * 数据表前缀
	 * @var string
	 */
	protected $tablePrefix = UC_TABLE_PREFIX;

	/**
	 * 数据库连接
	 * @var string
	 */
	protected $connection = UC_DB_DSN;

	/* 用户模型自动验证 */
	protected $_validate = array(
		array('password', '6,12','密码长度必须为6--12位', self::EXISTS_VALIDATE, 'length'), //密码长度不合法			
		array('password','/^\d*$/', '密码只能是数字！', self::EXISTS_VALIDATE , 'regex'),
	);

	/* 用户模型自动完成 */
	protected $_auto = array(
		array('password', 'think_ucenter_md5', self::MODEL_BOTH, 'function', UC_AUTH_KEY),
	);


	/**
	 * 用户登录认证
	 */
	public function login($studentid, $password){
		
		$map = array();		
		$map['studentid'] = $studentid;
		/* 获取用户数据 */
		$user = $this->where($map)->find();
		if(is_array($user)){
			/* 验证用户密码 */
			if(think_ucenter_md5($password, UC_AUTH_KEY) === $user['password']){				
				return $user['id']; //登录成功，返回用户ID
			} else {
				return -2; //密码错误
			}
		} else {
			return -1; //用户不存在或被禁用
		}
	}

	/**
	 * 获取用户信息
	 * @param  string  $uid         用户ID或用户名
	 * @param  boolean $is_username 是否使用用户名查询
	 * @return array                用户信息
	 */
	public function info($id, $is_username = false){
		$map = array();
		if($is_username){ //通过用户名获取
			$map['username'] = $uid;
		} else {
			$map['id'] = $uid;
		}

		$user = $this->where($map)->field('id,studentid,classes,name')->find();
		if(is_array($user)){
			return array($user['id'], $user['studentid'], $user['classes'], $user['name']);
		} else {
			return -1; //用户不存在或被禁用
		}
	}

	/**
	 * 更新用户信息
	 * @param int $uid 用户id
	 * @param string $password 密码，用来验证
	 * @param array $data 修改的字段数组
	 * @return true 修改成功，false 修改失败
	 * @author huajie <banhuajie@163.com>
	 */
	public function updateUserFields($uid, $password, $data){
		if(empty($uid) || empty($password) || empty($data)){
			$this->error = '参数错误！';
			return false;
		}

		//更新前检查用户密码
		if(!$this->verifyUser($uid, $password)){
			$this->error = '验证出错：密码不正确！';
			return false;
		}

		
		//更新用户信息
		$data = $this->create($data);
		if($data){
			return $this->where(array('id'=>$uid))->save($data);
		}
		return false;
	}

	/**
	 * 验证用户密码
	 */
	protected function verifyUser($uid, $password_in){
		$password = $this->getFieldById($uid, 'password');
		if(think_ucenter_md5($password_in, UC_AUTH_KEY) === $password){
			return true;
		}
		return false;
	}
	
	
	
	
	//后台修改密码
	public function updatePasswd($uid, $data){
		if(empty($uid) || empty($data)){
			$this->error = '参数错误！';
			return false;
		}
		//更新用户信息
		$data = $this->create(array('password'=>$data));
		if($data){
			return $this->where(array('id'=>$uid))->save($data);			
		}
		return false;
	}
	
	
	
	
	
	
	
	
	
	
	
	
}
