<?php
namespace Home\Controller;
use Think\Controller;

class NewsController extends HomeController {
    
	/* public function index($type){
    	if(!is_numeric($type))$this->error('类型错误');
    	$arr=array(0,1);
    	if(!in_array($type, $arr)){
    		$this->error('没有该类型');
    	}
    	
    	$data = M('news')->where(array('type'=>$type))->order('id desc')->select();
    	$title = $type==0?'好书推荐':'通知信息';
    	$this->assign('title',$title);	
    	$this->assign('data',$data);
    	$this->display();
    	
    } */
    
    public function book(){
        $data = M('news')->where(array('type'=>0))->order('id desc')->select();
        $this->assign('data',$data);
        $this->display();
    }
    
    public function OnlineRead(){
    	
    	$data = M('news')->where(array('type'=>2))->order('id desc')->select();
    	$this->assign('data',$data);
    	$this->display();
    	
    }
    
    public function notice(){
        $notice = M('news')->where(array('type'=>1))->order('id desc')->select();
        $note = M('nowday_sign')->where(array('share'=>2))->order('id desc')->select();
        $book = M('share_books')->order('id desc')->select();
        $this->assign('notice',$notice);
        $this->assign('note',$note);
        $this->assign('book',$book);
        $this->display();
    }
    
    public function showNotes($id=null){
        if(!preg_match("/^\d*$/",$id))	$this->error('id非法！');
        if(empty($id))  					$this->error('id不能为空!');
        $result=M('NowdaySign')->where(array('id'=>$id,'share'=>2))->find();
        if(!$result) 							$this->error('错误!');
         
        $this->assign('data',$result);
        $this->display();
    }
    
    public function showBook($id=null){
        if(!preg_match("/^\d*$/",$id))	$this->error('id非法！');
        if(empty($id))  					$this->error('id不能为空!');
        $result=M('share_books')->where(array('id'=>$id))->find();
        if(!$result) 							$this->error('错误!');
         
        $this->assign('data',$result);
        $this->display();
    }
    
    public function details($id){
    	
    	if(!preg_match("/^\d*$/",$page))	$this->error('id非法！');
    	if(empty($id))  					$this->error('id不能为空!');
    	   	
    	$data = M('news')->where(array('id'=>$id))->find();
    	if(!$data) 							$this->error('不存在该文章!');
    	
    	
    	$this->assign('data',$data);
    	$this->display();
    	
    }
    
    
}