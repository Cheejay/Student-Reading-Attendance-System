<?php
namespace Home\Controller;
use User\Api\UserApi;

/**
 * 后台用户控制器
 */
class UserController extends HomeController {
    public function index(){
    	if (IS_POST){
    		//获取参数
    		$uid        =   is_login();
    		$password   =   I('post.password');
    		$repassword = I('post.repassword');
    		$data['password'] = I('post.npassword');
    		empty($password) && $this->error('请输入原密码');
    		empty($data['password']) && $this->error('请输入新密码');
    		empty($repassword) && $this->error('请输入确认密码');
    		
    		if($data['password'] !== $repassword){
    			$this->error('您输入的新密码与确认密码不一致');
    		}
    		
    		$Api = new UserApi();
    		$res = $Api->updateInfo($uid, $password, $data);
    		if($res['status']){
    			$this->success('修改密码成功！');
    		}else{
    			$this->error($res['info']);
    		}
    		
    	}else{ 

    		$data = M('Member')->field('studentid,nickname,classname,campus,sex')->where(array('studentid'=>get_studentid()))->find();
    		
    		
    		$this->assign('data',$data);
    		$this->display('User/updatePasswd');	
    	}
    }
    
}