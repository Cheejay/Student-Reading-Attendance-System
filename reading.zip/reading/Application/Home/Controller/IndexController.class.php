<?php
namespace Home\Controller;
use Think\Controller;

class IndexController extends HomeController {
	
 	public function index(){
		$studentid = session('user_auth.studentid');
    	$list = M('member')->query("SELECT z.no FROM (SELECT @rownum:=@rownum+1 AS no,studentid FROM (SELECT m.studentid as studentid FROM rd_member m LEFT JOIN rd_sign s ON m.studentid=s.studentid ORDER BY score DESC,last_sign_time ASC) p,(SELECT @rownum:=0) r) z WHERE studentid=$studentid");
		$data=session('user_auth');
    	$this->assign('ranking',$list[0]['no']);
    	$this->assign('sinfo',$data);
    	$this->display();
    	
    }
	
}