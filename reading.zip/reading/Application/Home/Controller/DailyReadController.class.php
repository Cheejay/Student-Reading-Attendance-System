<?php
namespace Home\Controller;
use Think\Controller;

class DailyReadController extends HomeController {
	
    public function index(){
    	
    	$ws = M('weeklySchedule')->where(array('studentid'=>get_studentid(),'cycle'=>getCycle(),'termTime'=>Config('termTime')))->select();
    	$sna = M('sign')->where(array('studentid'=>get_studentid()))->find();
    	
    	$this->assign('sum_notes_amount',$sna['sum_notes_amount']);
		$this->assign('ws',$ws);
    	$this->display();	
    }
    
    /* 每天签到  */
    public function everydaySign(){
    	
    	$Book = D("BookList");
    	$Sign = D('Sign');
    	$totalDays = $Sign->where(array('studentid'=>get_studentid()))->find();
    	
    	if(IS_POST){
    		$bookid=I('post.bookid',0);    		
    		$page=I('post.page');
    		$content=I('post.content');
    		$notesAmount=mb_strlen($content, 'UTF-8');  		   		
    		$Book->verifyExist($bookid) || $this->error('请不要恶意添加！');//验证该本书的id是否真实存在
    		empty($content) && $this->error('笔记不能为空！');
    		if(!preg_match("/^\d*$/",$page)){
    			$this->error('请输入正确的页码！');
    		}
    		/*
    		if(!gltszf($content)){
    			$this->error('感悟里不能包含特殊字符！');
    		}
    		*/
    		if($notesAmount > 500){
    			$this->error('感悟不能超过500个字符！');
    		}
    		/* 判断每天只能签到一次 */
    		$time = M('NowdaySign')->where(array('studentid'=>get_studentid()))->order('sign_time desc')->find();
    		$lastTime = $time['sign_time'];//当天的0点
    		$nowTime  = date('Y-m-d',time());
			if($lastTime == $nowTime){
				$this->error('今天已经签到过了，请明天再来');
			}

			
    		
    		
    		$ws =M('WeeklySchedule')->where(array('studentid'=>get_studentid(),'bookid'=>$bookid,'cycle'=>getCycle(),'termTime'=>Config('termTime')))->find();
			//var_dump($ws);die;
    		
    		if(!$ws) $this->error('请先添加每周计划!');
    		
    		if($page <= $ws['sum_page']) $this->error("结束页码不该小于已经阅读的页码！");
    		$bookPage  = $Book->getBookPage($bookid);
    		if($page > $bookPage['bookpage']) $this->error('结束页码不能大于书本最大页数！');
    		
    		//判断该本书是否已经阅读完成，如果是则不让其继续签到
    		if($Book->getBookType($bookid) == 2) $this->error('恭喜你,该本书已经阅读完成！请选择其他书本继续阅读！');    		
    			
    		$data=array();
    		$data['notes'] 		  = mb_substr($content,0,500,'utf-8');//一次最多插入500个中文字符，多出的则忽略
    		$data['startpage']    = $ws['sum_page'];
    		$data['stoppage']     = $page;
    		$data['sign_days']    = $totalDays['total_days'] + 1;
    		$data['sign_time']    = date('Y-m-d',time());
    		$data['bookid']       = $bookid;
    		$data['studentid']    = get_studentid();
    		$data['notes_amount'] = $notesAmount;
    		$User = M("NowdaySign"); // 实例化User对象
    		$result=$User->data($data)->add();
			if(!$result){
				$this->error('签到失败,请联系管理员!');
			}
    		
			//写入书本阅读状态，为已阅读完
			if($page == $bookPage['bookpage']){
				$wanc = $Book->writeType(2,$bookid);
				$Sign->writeReadComplete();//写入完成阅读书本的数量
			}
			
			$sj = array(			
					'sum_page' => $page
			);
			$writePage = M('WeeklySchedule')->where(array('studentid'=>get_studentid(),'bookid'=>$bookid,'termTime'=>Config('termTime')))->save($sj);
			if(!$writePage){
				$this->error('写入总页数失败！');
			}
			
			$res =$Sign->writeSign($notesAmount);
    		if(!$res){
    			$this->error('写入总签到表失败！');
    		}else{	
    			$this->success('签到成功',U('DailyRead/showSign'));
    		}    		
    	}else{
    		
    		$data=$Book->getBooks();
    		$this->assign('bookn',$data);		
    		$this->assign('totalDays',$totalDays);
    		$this->display();
    	}
    }
    
    public function showSign(){
    	
    	$data=M('sign')->where(array('studentid'=>get_studentid()))->find();
    	$Signdata=M('NowdaySign')->field('id,studentid,bookid,sign_time,sign_days,startpage,stoppage')->where(array('studentid'=>get_studentid()))->order('sign_time desc')->select();

    	
    	$this->assign('Signdata',$Signdata);
    	$this->assign('days',$data);	
    	$this->display();
    }   
    
    
    public function showNotes($id=null){
    	
    	if(!preg_match("/^\d*$/",$id))	$this->error('id非法！');
    	if(empty($id))  					$this->error('id不能为空!');   	   	
    	$result=M('NowdaySign')->where(array('id'=>$id,'studentid'=>get_studentid()))->find();
    	if(!$result) 							$this->error('错误!');
    	
    	$this->assign('data',$result);
    	$this->display();
    }
    
    
    public function rule(){
    	
    	
    	$this->display();
    }
    
    public function share($id=null){
        if(!preg_match("/^\d*$/",$id))	$this->error('id非法！');
        if(empty($id))  					$this->error('id不能为空!');
        $result = M('nowday_sign')->where(array('id'=>$id,'studentid'=>get_studentid()))->find();
        if(!$result) 							$this->error('错误!');
        switch ($result['share']){
            case 1: $this->success('状态：等待管理员审核！');die; break;
            case 2: $this->success('状态：分享成功，已通过审核！');die; break;
        }
        $check = M('nowday_sign')->where(array('id'=>$id,'studentid'=>get_studentid()))->save(array('share'=>1));
        if(!$check) 							$this->error('错误!');
        $this->success('分享成功，等待管理员审核！再次点击分享可查看分享状态');
    }
    
    
}