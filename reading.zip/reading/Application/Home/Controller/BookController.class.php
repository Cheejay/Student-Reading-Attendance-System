<?php
namespace Home\Controller;
use Think\Controller;

class BookController extends HomeController {
	
	/*添加书本*/
    public function index(){
    	if(IS_POST){
    		$Book = D("BookList");
    		if($Book->create()){   			
    			$Book->verifyBookname(I('post.bookname')) && $this->error('请不要重复添加一本书！');    			
    			$result = $Book->add(); // 写入数据到数据库    			
    			if($result){
    				$this->success('添加成功！',U('Book/showBook'));
    			}else{
    				$this->error('添加失败！');
    			}  		
    		}else{
    			$this->error($Book->getError());
    		}
    	}else{
    		$this->display();  		
    	}    	
    }
    
    public function showBook(){
    	
    	
    	
    	$wyd = M('BookList')->where(array('statues'=>0,'studentid'=>get_studentid()))->select();		    	
    	$zyd = M('BookList')->where(array('statues'=>1,'studentid'=>get_studentid()))->select();		
    	$yyd = M('BookList')->where(array('statues'=>2,'studentid'=>get_studentid()))->select();		
    
    	
    	$data=array(
    		'wyd'=>count($wyd),
    		'zyd'=>count($zyd),
    		'yyd'=>count($yyd),	
    	);
    	
    	
    	$this->assign('wyd',$wyd);
    	$this->assign('zyd',$zyd);
    	$this->assign('yyd',$yyd);
    	$this->assign('data',$data);
    	
    	$this->display();
    }
    
    public function delete($id){
    	
    	if(!is_numeric($id)){
    		$this->error('id错误');
    	}
   	    if(!preg_match("/^\d*$/",$id)){
    		$this->error('id非法！');
    	}
    	$result = M('BookList')->where(array('studentid'=>get_studentid(),'id'=>$id))->find();
    	if(!$result){
    		$this->error('不存在该本书!');
    	}
    	
    	if($result['statues'] != 0){
    		$this->error('不允许删除正在阅读或已经阅读的书本！');
    	}
    	
    	$delete = M('BookList')->where(array('studentid'=>get_studentid(),'id'=>$id))->delete();
	
    	if($delete){
    		$this->success('删除成功!');
    	}else{
    		$this->error('删除失败!');
    		
    	}
    }
    
    public function share_books(){
        $book = M('BookList')->where(array('statues'=>2,'studentid'=>get_studentid()))->select();
        if(!$book) $this->error('您还没有完成阅读的书，无法晒书单');
        M('share_books')->where(array('studentid'=>get_studentid()))->delete();
        $data['studentid'] = get_studentid();
        $data['share_time'] = time();
        foreach($book as $vo){
            $data['content'].='书名:'.$vo['bookname'].'<br>作者：'.$vo['author']."<br>出版社：".$vo['press']."<br>页数：".$vo['bookpage']."<br><br>";
        }
        $result = M('share_books')->add($data);
        if(!$result) $this->error("操作失败！");
        $this->success('成功晒书单！');
    }
    
}