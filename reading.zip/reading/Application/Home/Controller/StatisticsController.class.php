<?php
namespace Home\Controller;
use Think\Controller;
use Think\Model;

class StatisticsController extends HomeController {
	
	
	
	
    public function index(){
    	$Model = M('member');
    	$book = M('book_list')
    			->field('bookname,author,author,bookpage,count(bookname) as number')
    			->group('bookname')
    			->order('number desc')
    			->limit(10)
    			->select();
    	$score_main = $Model
    			->join('LEFT JOIN rd_sign ON rd_member.studentid=rd_sign.studentid')
		    	->field('nickname,classid,score,last_sign_time')
		    	->where("campus like '主校区%'")
		    	->order('score desc,last_sign_time asc')
		    	->limit(30)
		    	->select();
    	
    	$score_branch = $Model
		    	->join('LEFT JOIN rd_sign ON rd_member.studentid=rd_sign.studentid')
		    	->field('nickname,classid,score,last_sign_time')
		    	->where("campus like '香华校区%'")
		    	->order('score desc,last_sign_time asc')
		    	->limit(30)
		    	->select();
    	
    	$score_class = $Model
    			->join('LEFT JOIN rd_sign ON rd_member.studentid=rd_sign.studentid')
		    	->field('nickname,classid,score,last_sign_time')
		    	->order('score desc,last_sign_time asc')
		    	->limit(10)
		    	->where(array('classid'=>session('user_auth.classid')))
		    	->select();
    	
    	$class_main = $Model
    			->field('classid,sum(total_days) as total_days,sum(score) as score,avg(score) as avg_score,sum(sum_ws) as sum_ws')
    			->join('LEFT JOIN rd_sign ON rd_member.studentid=rd_sign.studentid')
    			->where("campus like '主校区%'")
    			->group('classid')
    			->order('avg_score desc,score desc')
    			->limit(10)
    			->select();
    	
    	$class_branch = $Model
		    	->field('classid,sum(total_days) as total_days,sum(score) as score,avg(score) as avg_score,sum(sum_ws) as sum_ws')
		    	->join('LEFT JOIN rd_sign ON rd_member.studentid=rd_sign.studentid')
		    	->where("campus like '香华校区%'")
		    	->group('classid')
		    	->order('avg_score desc,score desc')
		    	->limit(10)
		    	->select();
    	
    	$this->assign('book',$book);
    	$this->assign('score_main',$score_main);
    	$this->assign('score_branch',$score_branch);
    	$this->assign('score_class',$score_class);
    	$this->assign('class_main',$class_main);
    	$this->assign('class_branch',$class_branch);
    	$this->display();
    }
}