<?php
namespace Home\Controller;
use Think\Controller;

//每周计划控制器
class WeeklyScheduleController extends HomeController{
	

	/* 计划列表 */
    public function index(){
		$data=D('WeeklySchedule')->getWS();
		$this->assign('data',$data);
    	$this->display();
    }
    
    /*  每周计划添加  */
    public function add(){
    	if(IS_POST){    
    		$Weekly = D('WeeklySchedule');
    		if($Weekly->create()){ 
   			
    			$Book = D("BookList");				    	
    			//验证是否是随意添加
    			$Book->verifyExist(I('post.bookid',0)) || $this->error('请不要恶意添加！');
    			if($Weekly->verifyWeeklyAmount() >= 5){
    				$this->error('每周最多只能有五个读书计划!');
    			}
    			if($Weekly->verifyBookname(I('post.bookid',0))){
    				$this->error('本周计划里已经存在该本书了，请不要重复添加！');
    			}
    			
    			$countPage=$Book->getBookPage(I('post.bookid',0));
    			(I('post.planpage',0) > $countPage['bookpage']) && $this->error('计划页数不能大于总页数!');
    			
    			
    			$result =$Weekly->add(); // 写入数据到数据库
    			if($result){
    				$Book->writeType(1,I('post.bookid',0));//标记该本书为已读状态
    				$oneWS = M('WeeklySchedule')->where(array('studentid'=>get_studentid(),'cycle'=>getCycle(),'termTime'=>Config('termTime')))->select(); 				
    				if(count($oneWS) == 1){
    					$score = array(
    						'score' => array('exp', '`score`+50'),
    					);
    					
    					$re = M('Member')->where(array('studentid'=>get_studentid()))->save($score);    					  					
    				}
    				D('Sign')->writeCycle();//写入制定计划的次数
    				$this->success('添加成功！');
    			}else{
    				$this->error('添加失败！');
    			}
    		}else{
    			$this->error($Weekly->getError());
    		}
    	}else{    		
    		$data=D('BookList')->getBooks();
    		$this->assign('data',$data);   		
    		$this->display();
    	}    	
    }   
}