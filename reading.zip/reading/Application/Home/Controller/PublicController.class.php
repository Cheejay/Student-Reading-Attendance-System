<?php
namespace Home\Controller;
use User\Api\UserApi;
use Think\Verify;

class PublicController extends \Think\Controller {

    /**
     * 用户登录
     */
    public function login($studentid = null, $password = null,$verify = null){
        if(IS_POST){
        	
        	if(!check_verify($verify,1)){
        		$this->error('验证码输入错误！');
        	}
        	
            /* 调用UC登录接口登录 */
            $User = new UserApi;
            $uid = $User->login($studentid, $password);       
            if(0 < $uid){ //UC登录成功
                /* 登录用户 */
                $Member = D('Member');
                if($Member->login($uid)){ //登录用户
                    //TODO:跳转到登录前页面
                    $this->redirect('Index/index');
                } else {
                    $this->error($Member->getError());
                }

            } else { //登录失败
                switch($uid) {
                    case -1: $error = '用户不存在或者被禁用！'; break; //系统级别禁用
                    case -2: $error = '密码错误！'; break;
                    default: $error = '未知错误！'; break; // 0-接口参数错误（调试阶段使用）
                }
                $this->error($error);
            }
        } else {
        	$this->display(':User/login');
        }
    }

    /* 退出登录 */
    public function logout(){
        if(is_login()){
            D('Member')->logout();
            session('[destroy]');
            $this->success('退出成功！', U('login'));
        } else {
            $this->redirect('login');
        }
    }
    
    /* 验证码，用于登录和注册 */
    public function verify(){
    	ob_clean();
    	$Verify =     new \Think\Verify();
    	$Verify->codeSet = '0123456789';
		$Verify->fontSize = 45;
		$Verify->length   = 4;
		$Verify->useNoise = false;
		$Verify->entry(1);
    }
}
