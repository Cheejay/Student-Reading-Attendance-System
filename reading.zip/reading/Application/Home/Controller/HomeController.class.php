<?php
namespace Home\Controller;
use Think\Controller;

class HomeController extends Controller {

	/* 空操作，用于输出404页面 */
	public function _empty(){
		$this->redirect('Index/index');
	}


    protected function _initialize(){
    	
    	
    	if(Config('onOff')!=1) die('The site is being updated and maintenance, please wait patiently!');
    	
    	$this->login();
    	
    	
    }

	/* 用户登录检测 */
	protected function login(){
		/* 用户登录检测 */
		is_login() || $this->redirect('Public/login');
	}

}
