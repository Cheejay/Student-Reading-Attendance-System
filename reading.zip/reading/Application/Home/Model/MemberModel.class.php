<?php
namespace Home\Model;
use Think\Model;
use User\Api\UserApi;

/**
 * 文档基础模型
 */
class MemberModel extends Model{
	
    /**
     * 登录指定用户
     */
    public function login($uid){
        /* 检测是否在当前应用注册 */
        $user = $this->field(true)->find($uid);
        if(!$user){ //未注册       
            $this->error = '登陆失败！';
            return false;
        } elseif(1 != $user['status']) {
            $this->error = '用户未已禁用！';
            return false;
        }

        /* 登录用户 */
        $this->autoLogin($user);
        return true;
    }

    /**
     * 注销当前用户
     * @return void
     */
    public function logout(){
        session('user_auth', null);
        session('user_auth_sign',null);
    }

    /**
     * 自动登录用户
     * @param  integer $user 用户信息数组
     */
    private function autoLogin($user){
        /* 记录登录SESSION和COOKIES */
        $auth = array(
            'id'             => $user['id'],
            'studentid'      => $user['studentid'],
        	'nickname'		 => $user['nickname'],
        	'classid'		 => $user['classid'],	
        );
        session('user_auth', $auth);
        session('user_auth_sign', data_auth_sign($auth));
    }
    
    
    
    
    /*
     *写入积分 
     * 
     */
    public function sumScore($score){
    	/* 更新信息 */
    	$data = array(  			
    			'score' => array('exp', '`score`+"'.$score.'"'),
    	);
    	
    	$res=$this->where(array('studentid'=>get_studentid()))->save($data);
    	if(!$res){
    		return false;
    	}
    	return true;
    	
    }
    
    
    
    
    
    
    

}
