<?php
namespace Home\Model;
use Think\Model;

/**
 * 书本模型
 */
class BookListModel extends Model{

	protected $insertFields = array('bookname','author','bookpage','press');
	//protected $updateFields = array('nickname','email');
	
    protected $_validate = array(
        array('bookname', 'require', '书本名称不能为空', self::EXISTS_VALIDATE, 'regex', self::MODEL_INSERT),
        array('author', 'require', '作者不能为空', self::MUST_VALIDATE , 'regex', self::MODEL_INSERT),
    	array('bookpage', 'require', '页数不能为空', self::MUST_VALIDATE , 'regex', self::MODEL_INSERT),
    	array('press', 'require', '出版社不能为空', self::MUST_VALIDATE , 'regex',self::MODEL_INSERT),    	
    			
    	//限制长度	
    	array('bookname', '1,20', '书本名称不能超过20个字符', self::VALUE_VALIDATE , 'length', self::MODEL_INSERT),
    	array('author', '1,10', '作者名称不能超过10个字符', self::VALUE_VALIDATE , 'length', self::MODEL_INSERT),
    	array('bookpage', '1,6', '页数不能超过6个字符', self::VALUE_VALIDATE , 'length', self::MODEL_INSERT),
    	array('press', '1,30', '出版社名称不能超过30个字符', self::VALUE_VALIDATE , 'length', self::MODEL_INSERT),
    		
    	//过滤特殊字符
    	array('bookname','gltszf','书本名不允许特殊字符！',self::VALUE_VALIDATE,'function',self::MODEL_INSERT),
    	array('author','gltszf','出版社名不允许特殊字符！',self::VALUE_VALIDATE,'function',self::MODEL_INSERT),
    	array('press','gltszf','作者名不允许特殊字符！',self::VALUE_VALIDATE,'function',self::MODEL_INSERT),
    	array('bookpage','/^\d*$/', '页数必须为数字', self::VALUE_VALIDATE , 'regex', self::MODEL_INSERT),
    );

    protected $_auto = array(
        array('studentid','get_studentid', self::MODEL_INSERT,'function'),
    	array('create_time', 'time', self::MODEL_INSERT, 'function'),
    );

    
    /* 防止用户重复添加同一本书 */
    public function verifyBookname($name){
    	$map=array();
    	$map['studentid'] = get_studentid();
    	$map['bookname'] = $name;
    	return is_array($this->where($map)->find())?1:0;    	
    }
    
    /* 判断书本是否真实存在 */
    public function verifyExist($bookid){
    	if(!is_numeric($bookid) || $bookid==''){
    		return 0;
    	}    	
    	$map=array();
    	$map['id'] = $bookid;
    	$map['studentid'] = get_studentid(); 	
    	return is_array($this->where($map)->find())?1:0;
    }
    
    /* 返回所有书本信息 */    
    public function getBooks(){    	
    	return $this->field('id,bookname')->where(array('studentid'=>get_studentid()))->order('statues asc,id desc')->select();    	
    }
    
    /* 返回所有书本页数 */
    public function getBookPage($bookid){
    	if(!is_numeric($bookid) || $bookid==''){
    		return 0;
    	}    	
    	$map=array();
    	$map['id'] = $bookid;
    	$map['studentid'] = get_studentid(); 	
    	return $this->field('bookpage')->where($map)->find();
    }
    
    
   
   //写入书本的状态 
    public function writeType($statues,$bookid){
    	
    	/*  0是未阅读，1是开始阅读，2是阅读完毕  */
    	
    	$data = array(
    			'statues' => $statues
    	);
    	$re=$this->where(array('studentid'=>get_studentid(),'id'=>$bookid))->save($data);
    	if(!re){
    		return false;
    	}else{
    		return true;	
    	}
    }
    
    //返回这本书现在的阅读状态
   public function getBookType($bookid){
   		
   		$book=$this->where(array('studentid'=>get_studentid(),'id'=>$bookid))->find();
   		return $book['statues'];
   }
    
    
    
    
    
    
    
}
