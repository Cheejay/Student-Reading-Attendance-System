<?php
namespace Home\Model;
use Think\Model;
class SignModel extends Model{

    /* 用户模型自动完成 */
    protected $_auto = array(
    	array('studentid','get_studentid',self::MODEL_INSERT,'function'),
    );

    public function writeSign($notesAmount){
    	    
        $user = $this->where(array('studentid'=>get_studentid()))->find();
        if($user['last_sign_time'] == 0){ //第一次签到         
            $user =	array(
            			  'continuous_sign_days'=>1,
            			  'total_days' =>1,
            			  'sum_notes_amount'=>$notesAmount,
            			  'last_sign_time'=>time()         		
            );      
        	$re=$this->where(array('studentid'=>get_studentid()))->save($user);
        	if(!re){
        		return false;
        	}
            
            //签到第一次的积分
            M('Member')->where(array('studentid'=>get_studentid()))->save(array('score' => array('exp', '`score`+10')));
            return true;
            
        }else{//修改原有的数据

        	$lastTime = strtotime(date('Y-m-d',$user['last_sign_time']));//当天的0点
        	$nowTime  = time();
        	$nowMaxTime = $lastTime + (24*60*60)+(24*60*60);        	
        	//证明没有超过24小时，可以连续签到。如果连续签到了七天，则下一次签到为第一天
        	if($nowTime < $nowMaxTime){        		
        		if($user['continuous_sign_days'] == 7){
        			$ContinuousSign = 1;
        		}else{
        			$ContinuousSign = array('exp', '`continuous_sign_days`+1');
        		}
        	}else{
        		$ContinuousSign = 1;       		
        	}
        	
        	
        	/* 更新信息 */
        	$data = array(        			
        			'continuous_sign_days' => $ContinuousSign,
        			'total_days' => array('exp', '`total_days`+1'),
        			'sum_notes_amount'=>array('exp', '`sum_notes_amount`+"'.$notesAmount.'"'),
        			'last_sign_time' => time()
        	);
        	$re=$this->where(array('studentid'=>get_studentid()))->save($data);
        	if(!re){
        		return false;
        	}
        	
        	//写入签到积分
        	$score = getCsd();
        	$score = $score * 10;
        	$sc = D('Member')->sumScore($score);
        	if(!sc){       		
        		return false;
        	}
   	
			return true;       	
        }
        
    }
    
    /* 写入制定计划的次数 */
    public function writeCycle(){  	
    	$user = $this->where(array('studentid'=>get_studentid()))->find();
    	if(!$user){ //第一次制定计划 		 
    		$user = $this->create(array('sum_ws'=>1));
    		if(!$this->add($user)){
    			$this->error = '无法将数据写入总签到表！';
    			return false;
    		}
    		return true;  	
    	}else{//修改原有的数据	
    		/* 更新信息 */
    		$data = array('sum_ws' => array('exp', '`sum_ws`+1'));
    		$re=$this->where(array('studentid'=>get_studentid()))->save($data);
    		if(!re){
    			return false;
    		}	
    		return true;
    	}	
    }
    
    /* 写入完成阅读的次数 */
    public function writeReadComplete(){  	
    	/* 更新信息 */
    	$data = array('complete_read' => array('exp', '`complete_read`+1'));
    	$re=$this->where(array('studentid'=>get_studentid()))->save($data);
    	if(!re){
    		return false;
    	}
    	return true;
    }
    
    
    
    
}
