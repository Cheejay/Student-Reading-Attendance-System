<?php
namespace Home\Model;
use Think\Model;

/**
 * 书本模型
 */
class WeeklyScheduleModel extends Model{

	protected $insertFields = array('bookid','planpage','readtime','create_time','sum_page');
	//protected $updateFields = array('nickname','email');
	
    protected $_validate = array(
        array('planpage', 'require', '计划阅读数不能为空', self::MUST_VALIDATE , 'regex', self::MODEL_INSERT),
    	array('readtime', 'require', '阅读时间不能为空', self::MUST_VALIDATE , 'regex', self::MODEL_INSERT),
		
    	array('planpage', '1,10', '计划阅读数不能超过10个字符', self::VALUE_VALIDATE , 'length', self::MODEL_INSERT),    	
    	array('readtime', '1,30', '阅读时间不能超过30个字符', self::VALUE_VALIDATE , 'length', self::MODEL_INSERT),

    	//过滤特殊字符
    	array('planpage','/^\d*$/', '计划阅读数必须为数字', self::VALUE_VALIDATE , 'regex', self::MODEL_INSERT),
    	array('readtime','/^([0-5]\d):([0-5]\d)$/', '阅读时间格式错误！', self::VALUE_VALIDATE , 'regex', self::MODEL_INSERT),
    		
    		
    );

    protected $_auto = array(
    	array('cycle','getCycle',self::MODEL_INSERT,'function'),
        array('studentid','get_studentid', self::MODEL_INSERT,'function'),
    	array('create_time', 'time', self::MODEL_INSERT, 'function'),
    	array('sum_page','0',self::MODEL_INSERT),
    	array('termTime','Config',self::MODEL_INSERT,'function',array('termTime')),
    );

    
    /* 防止用户重复添加同一本书 */
    public function verifyBookname($bookid){
    	$map=array();
    	$map['studentid'] = get_studentid();
    	$map['bookid']    = $bookid;
    	$map['cycle']     = getCycle();
    	$map['termTime']  = Config('termTime');
    	return is_array($this->where($map)->find())?1:0;    	
    }
    
    /* 返回 每周计划 */
    public function getWS(){
    	$map=array();
    	$map = get_studentid();
    	$db=new Model();
		$rs = $db->query("SELECT * FROM rd_Weekly_Schedule WHERE studentid='$map' order by termtime desc");
		$k=0;   
		foreach($rs as $row){
			$t=$row['termtime']."学期第".$row['cycle']."周计划";
		    $arr[$t][$k]= $row;
		    $k++;
		}
    	
    	return $arr;
    }
    
    //统计学生的每周读书计划数量
    public function verifyWeeklyAmount(){
    	$map=array();
    	$map['cycle'] = getCycle();/*当前周期*/
    	$map['studentid'] = get_studentid();
    	$map['termTime']  = Config('termTime');
    	$arr=$this->where($map)->select();
    	return count($arr);
    }
     
}
