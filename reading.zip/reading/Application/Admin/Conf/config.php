<?php
return array(
	/* 主题设置 */
	'DEFAULT_THEME' =>  'default',  // 默认模板主题名称
	
	/* 模板相关配置 */
	'TMPL_PARSE_STRING' => array(
			'__IMG__'    => __ROOT__ . '/Public/' . MODULE_NAME . '/images',
			'__CSS__'    => __ROOT__ . '/Public/' . MODULE_NAME . '/css',
			'__JS__'     => __ROOT__ . '/Public/' . MODULE_NAME . '/js',
			'__PLUGINS__'=> __ROOT__ . '/public/' . MODULE_NAME . 'plugins',
	),
	
	/* SESSION 和 COOKIE 配置 */
	'SESSION_PREFIX' => 'reading_admin', //session前缀
);