<?php
namespace Admin\Model;
use Think\Model;

class AdminModel extends Model {

	
	protected $_validate = array(
			array('username', '6,12', '用户名为为6-12个字符', self::EXISTS_VALIDATE, 'length'),
			array('username', '', '昵称被占用', self::EXISTS_VALIDATE, 'unique'), //用户名被占用
			array('password', '6,12', '密码长度为6-12个字符', self::EXISTS_VALIDATE, 'length'),
	);
	protected $_auto = array(
			array('password', 'think_ucenter_md5_admin', self::MODEL_BOTH, 'function', UC_AUTH_KEY),
			array('status','1',self::MODEL_BOTH),
			array('user_type',2,self::MODEL_BOTH),
			array('create_time', 'time', self::MODEL_BOTH, 'function'),
	);
	
    /**
     * 登录指定用户
     */
    public function login($uid){
        /* 检测是否在当前应用注册 */
        $user = $this->field(true)->find($uid);
        if(!$user || 1 != $user['status']) {
            $this->error = '用户不存在或已被禁用！'; //应用级别禁用
            return false;
        }
        /* 登录用户 */
        $this->autoLogin($user);
        return true;
    }

    /**
     * 注销当前用户
     */
    public function logout(){
        session('user_auth', null);
        session('user_auth_sign', null);
    }

    /**
     * 自动登录用户
     */
    private function autoLogin($user){

    	$arr=array(
    			'last_login_time'=>time(),
    	);
    	$this->where(array('id'=>$user['id']))->save($arr);

        /* 记录登录SESSION和COOKIES */
        $auth = array(
            'id'             => $user['id'],
            'username'       => $user['username'],
        	'user_type'		 => $user['user_type'],
        );

        session('user_auth', $auth);
        session('user_auth_sign', data_auth_sign($auth));

    }
}
