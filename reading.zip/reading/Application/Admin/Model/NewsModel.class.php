<?php
/**
 * Created by PhpStorm.
 * User: zbmacro
 * Date: 2016/3/16
 * Time: 13:48
 */
namespace Admin\Model;
use Think\Model;

class NewsModel extends Model{
    protected $_validate = array(
        array('type' ,'0,1,2' ,'类型错误!' ,1 ,'in' ,1),
        array('title' ,'require' ,'请输入标题！' ,1 ,'regex' ,3),
        array('title' ,'(1,40)' ,'标题字符长度不允许超过40！' ,0 ,'length' ,3),
        array('abstract' ,'require' ,'请输入摘要！' ,1 ,'regex' ,3),
        array('abstract' ,'(1,250)' ,'摘要字符长度不允许超过250！' ,0 ,'length' ,3),
        array('content' ,'require' ,'请输入内容！' ,1 ,'regex' ,3),
        array('content' ,'(1,100000)' ,'内容字符长度不允许超过100000！' ,0 ,'length' ,3),
    );

    protected $_auto = array(
        array('time' ,'time' ,1 ,'function'),
    );
}