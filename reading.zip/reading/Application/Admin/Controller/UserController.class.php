<?php
/**
 * Created by PhpStorm.
 * User: zbmacro
 * Date: 2016/3/17
 * Time: 11:29
 */
namespace Admin\Controller;
use Think\Controller;

class UserController extends AdminController{
    public function _initialize(){
    	parent::_initialize();
        $this->model = D('Admin');
    }

    public function index(){
        $list = $this->model->order('create_time DESC')->select();
        $this->assign('list',$list);
        $this->display();
    }

    public function add(){
        $this->display();
    }

    public function add_post($username,$password,$repassword){
    		/* 检测密码 */
			if($password != $repassword){
				$this->error('密码和重复密码不一致！');
			}			
			if($this->model->create()){
				
				$this->model->add()!==false ? $this->success('添加成功！',U('index')) : $this->error('添加失败');
			}else{
				$this->error($this->model->getError());
			}			
		
    }

    public function delete(){
    	if(session('user_auth.user_type') != 1) $this->error('只有超级管理员才有此权限！');
    	if(I('get.id')==session('user_auth.id')){
    		$this->error('不能删除自己！');
    	}
        $result = $this->model->delete(trim(I('get.id')));
        $result!==false ? $this->success('删除成功！') : $this->error('删除失败!');
    }

    public function status(){
    	if(session('user_auth.user_type') != 1) $this->error('只有超级管理员才有此权限！');
    	if(I('get.id')==session('user_auth.id')){
    		$this->error('不能禁用自己！');
    	}
        $result = $this->model->where(array('id'=>trim(I('get.id'))))->save(array('status'=>trim(I('get.status'))));
        $result!==false ? $this->success('操作成功！') : $this->error('操作失败!');
    }
}