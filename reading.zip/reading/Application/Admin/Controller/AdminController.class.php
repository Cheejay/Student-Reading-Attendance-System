<?php
namespace Admin\Controller;
use Think\Controller;

class AdminController extends Controller {

	/* 空操作，用于输出404页面 */
	public function _empty(){
		$this->redirect('Index/index');
	}


    protected function _initialize(){	
    	
    	$this->login();
    	
    	/*
    	 *设置普通管理员允许访问的控制器
    	 *目前只允许访问index控制器，如需更改可手动添加
    	 */
    	$permit = array('Index');
    	 
    	if(session('user_auth.user_type')!=1){
    	
    		$Controller =  CONTROLLER_NAME;
    		$result     =  in_array($Controller, $permit)?true:false;
    		if($result===false) $this->redirect('Index/class_week');   	
    	}
    
    }

	/* 用户登录检测 */
	protected function login(){
		/* 用户登录检测 */
		is_login() || $this->redirect('Public/login');
	}

}
