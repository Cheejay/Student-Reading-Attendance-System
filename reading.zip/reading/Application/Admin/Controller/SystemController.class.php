<?php
namespace Admin\Controller;

Class SystemController extends AdminController{
    
    public function  index(){
        $termTime = M('Config')->find(1);
        $start = M('Config')->find(2);
        $onOff = M('Config')->find(3);
        $config = array(
            'termTimes' => $termTime['value'],
            'termTimes_details' => $termTime['details'],
            'start' => date('Y-m-d',$start['value']),
            'start_details' => $start['details'],
            'onOff' => $onOff['value'],
        );
        $this->assign($config);
        $this->display();
    }
    
    public function save(){
        $termTime = M('Config')->save(array('id'=>1,'value'=>$_POST['termTime']));
        $start = M('Config')->save(array('id'=>2,'value'=>strtotime($_POST['start'])));
        $onOff = M('Config')->save(array('id'=>3,'value'=>$_POST['onOff']));
        if($termTime!==false && $start!==false && $onOff!==false){
            $this->success("修改成功！");
        }else{
            $this->error("修改失败！");
        }
    }
}