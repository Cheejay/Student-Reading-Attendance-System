<?php
/**
 * Created by PhpStorm.
 * User: zbmacro
 * Date: 2016/3/21
 * Time: 8:22
 */
namespace Admin\Controller;
use Think\Controller;

class BookController extends AdminController{
    public function _initialize(){
    	parent::_initialize();
        $this->Model = M('book_list');
    }

    public function studentBook(){
        $list = $this->Model->field('bookname,author,press,bookpage,create_time')->where(array('studentid'=>I('get.studentid'),'statues'=>2))->select();
        $this->assign('list',$list);
        $this->display('book');
    }

    public function classBook(){
        $list = $this->Model->join('RIGHT JOIN rd_member ON rd_member.studentid=rd_book_list.studentid')->field('bookname,author,press,bookpage,create_time')->where(array('classid'=>I('get.classid'),'statues'=>2))->group('bookname')->order('create_time DESC')->select();
        $this->assign('list',$list);
        $this->display('book');
    }

    public function hot(){
        $list = M('book_list')->field('bookname,author,press,bookpage,count(id) as number')->group('bookname')->order('number DESC')->limit(10)->select();
        $this->assign('list',$list);
        $this->display();
    }
}