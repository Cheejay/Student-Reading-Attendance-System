<?php
/**
 * Created by PhpStorm.
 * User: zbmacro
 * Date: 2016/3/16
 * Time: 10:50
 */
namespace Admin\Controller;
use Think\Controller;

class NewsController extends AdminController{
    public function _initialize(){
    	
    	parent::_initialize();
    	
        $this->News = D('News');
        switch(I('request.type')) {
            case 0:
                $this->name = "好书推荐";
                $this->type = 0;
                break;
            case 1:
                $this->name = "通知信息";
                $this->type = 1;
                break;
            case 2:
                $this->name = "在线阅读";
                $this->type = 2;
                break;
            default:
                $this->error("页面不存在！");
        }
        $this->assign('name',$this->name);
        $this->assign('type',$this->type);
    }

    public function index(){
        isset($_POST['like'])?$where['title'] = array('like',"%{$_POST['like']}%"):false;
        $where['type'] = $this->type;
        $list = $this->News->where($where)->order('time DESC')->select();
        $this->assign('list',$list);
        $this->assign('like',I('post.like'));
        $this->display();
    }

    public function add(){
        $this->display();
    }

    public function add_post(){
        if($data = $this->News->create()){
        	
            if(!empty($_FILES['picture']['name'])){
                $upload = new \Think\Upload();
                $upload->maxSize = 3145728 ;
                $upload->exts = array('jpg', 'gif', 'png', 'jpeg');
                $upload->rootPath =  './Public/Uploads/';
                $info = $upload->upload();
                if(!$info) {
                    $this->error($upload->getError());
                }else {
                    $data['content'] = htmlspecialchars_decode($data['content']);
                    $data['uid'] = session('user_auth.id');
                    $data['picture'] = date('Y-m-d').'\\'.$info['picture']['savename'];
                    if($this->News->add($data)!==false){
                        $this->success('发布成功！',U('index',array('type'=>$this->type)));
                    }else{
                        $this->error('发布失败！');
                    }
                }
            }else{
                $this->error('请选择预览图！');
            }
        }else{
        	var_dump($this->News->create());die;
            $this->error($this->News->getError());
        }
    }

    public function edit(){
        $list = $this->News->find(trim(I('get.id')));
        $this->assign($list);
        $this->display();
    }

    public function edit_post(){
        if($data = $this->News->create()){
            if(!empty($_FILES['picture']['name'])){
                $upload = new \Think\Upload();
                $upload->maxSize = 3145728 ;
                $upload->exts = array('jpg', 'gif', 'png', 'jpeg');
                $upload->rootPath =  './Public/Uploads/';
                $info = $upload->upload();
                if(!$info) {
                    $this->error($upload->getError());exit();
                }
                $data['picture'] = date('Y-m-d').'\\'.$info['picture']['savename'];
            }
            $data['content'] = htmlspecialchars_decode($data['content']);
            if($this->News->save($data)!==false){
                $this->success('发布成功！',U('index',array('type'=>$this->type)));
            }else{
                $this->error('发布失败！');
            }
        }else{
            $this->error($this->News->getError());
        }
    }

    public function delete(){
        $this->News->delete(trim(I('get.id')))!==false ? $this->success('删除成功！') : $this->error('删除失败!');
    }
    
    public function share(){
        $data = M('nowday_sign')->where('share=1 or share=2')->order('share asc')->select();
        $this->assign('data',$data);
        $this->display();
    }
    
    public function update_share($id=null,$share=null){
        $result = M('nowday_sign')->save(array('id'=>$id,'share'=>$share));
        if(!$result) $this->error('操作失败!');
        $this->success('操作成功！');
    }
}