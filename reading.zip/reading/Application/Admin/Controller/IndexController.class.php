<?php
namespace Admin\Controller;
use Think\Controller;
class IndexController extends AdminController{
	
    public function index(){
        $person_main = $this->select("campus like '主校区%'" ,'rd_member.studentid,classid,nickname,sum_ws,total_days,complete_read,sum_notes_amount,score,last_sign_time' ,null ,30);
        $person_branch = $this->select("campus like '香华校区%'" ,'rd_member.studentid,classid,nickname,sum_ws,total_days,complete_read,sum_notes_amount,score,last_sign_time' ,null ,30);
        $class_main = $this->select("campus like '主校区%'" ,'grade,classid,count(rd_member.id) as number,sum(sum_ws) as sum_ws,sum(total_days) as total_days,sum(complete_read) as complete_read,sum(sum_notes_amount) as sum_notes_amount,sum(score) as score,avg(score) as avg_score' ,'classid' ,0 ,'avg_score DESC,');
        $class_branch = $this->select("campus like '香华校区%'" ,'grade,classid,count(rd_member.id) as number,sum(sum_ws) as sum_ws,sum(total_days) as total_days,sum(complete_read) as complete_read,sum(sum_notes_amount) as sum_notes_amount,sum(score) as score,avg(score) as avg_score' ,'classid' ,0 ,'avg_score DESC,');
        $this->assign('person_main',$person_main);
        $this->assign('person_branch',$person_branch);
        $this->assign('class_main',$class_main);
        $this->assign('class_branch',$class_branch);
        $this->display();
    }

    public function class_week(){
        if(IS_POST) {
            $list = $this->select(array('classid'=>trim(I('post.class'))) ,'rd_member.studentid,classid,nickname,sum_ws,total_days,complete_read,sum_notes_amount,score,last_sign_time');
            $this->assign('list',$list);
            $this->assign('class', trim(I('post.class')));
        }
        $this->display();
    }

    private function select($where ,$field='*' ,$group=null ,$limit=0,$order=null){
        return M('member')
           // ->fetchSql(true)
                ->join('LEFT JOIN rd_sign ON rd_member.studentid=rd_sign.studentid')
                ->field($field)
                ->where($where)
                ->order($order.'score DESC,last_sign_time asc')
                ->group($group)
                ->limit($limit)
                ->select();
    }
}