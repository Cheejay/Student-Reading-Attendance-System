<?php
/**
 * Created by PhpStorm.
 * User: zbmacro
 * Date: 2016/3/16
 * Time: 9:17
 */
namespace Admin\Controller;
use Think\Controller;
use User\Api\UserApi;

class StudentController extends AdminController{
    public function _initialize() {
    	parent::_initialize();
        $this->member = M('Member');
    }

    public function index(){
        $this->display();
    }

    public function select(){
        isset($_POST['studentid']) ? $where['studentid']=trim(I('post.studentid')) : $where['nickname']=array('like',trim(I('post.nickname')).'%');
        $list = $this->member->where($where)->select();
        $this->assign('list',$list);
        $this->assign('studentid',I('post.studentid'));
        $this->assign('nickname',I('post.nickname'));
        $this->display('index');
    }

    public function password(){
        $list = $this->member->find(trim(I('get.id')));
        $this->assign($list);
        $this->display();
    }

    public function change(){
    	//获取参数
    	$uid        =   I('post.id');
    	$password   =   I('post.password');
    	empty($password) && $this->error('请输入密码');
    	   	
    	$Api = new UserApi();
    	$res = $Api->updatePasswd($uid, $password);
    	if($res['status']){
    		$this->success('修改密码成功！');
    	}else{
    		$this->error($res['info']);
    	}
    	
    }

    public function status(){
        $result = $this->member->where(array('id'=>trim(I('get.id'))))->save(array('status'=>trim(I('get.status'))));
        $result!==false ? $this->success('操作成功！') : $this->error('操作失败!');
    }
}
