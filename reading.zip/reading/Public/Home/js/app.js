function credit(){
	var xzRule = 300;
	var integral = parseInt($(".star .integral").text());
	var xzList = $(".star .medal_list");
	var starList = $(".star .star_list");
	var xz = Math.floor(integral / xzRule);
	var star = Math.floor(xz / 3);
	var xz3;
	if(xz > 2 && integral < 5040){
		xz3 = parseInt(xz / 3);
		xz -= xz3 * 3;
	}
	for(var i = 0;i < xz;i++){
		xzList.eq(i).addClass("medal_active");
	}
	for(var i = 0;i < star;i++){
		starList.eq(i).addClass("star_active");
	}
}
function showDiaLog(){
	var showDiaLogImg = $(".showDiaLogImg");
	var time = 3000;
	showDiaLogImg.fadeIn("slow");
	setInterval(function(){
		showDiaLogImg.fadeOut("slow");
	},time)
}